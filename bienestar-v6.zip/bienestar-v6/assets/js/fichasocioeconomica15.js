// DATOS GENERALES
const frm_infoalumno = document.querySelector('#frmInfoAlumno');
const id_alumno_dg = document.querySelector('#id_alumno_dg');
const nombres_dg = document.querySelector('#nombres_dg');
const apellidopaterno_dg = document.querySelector('#apellidopaterno_dg');
const apellidomaterno_dg = document.querySelector('#apellidomaterno_dg');
const fechadenacimiento_dg = document.querySelector('#fechadenacimiento_dg');
const edad_dg = document.querySelector('#edad_dg');
const genero_dg = document.querySelector('#genero_dg');
const dni_dg = document.querySelector('#dni_dg');
const telefonocelular_dg = document.querySelector('#telefonocelular_dg');
const correo_dg = document.querySelector('#correo_dg');
const domicilioactual_dg = document.querySelector('#domicilioactual_dg');
const departamentoda_dg = document.querySelector('#departamentoda_dg')
const provinciada_dg = document.querySelector('#provinciada_dg')
const distritoda_dg = document.querySelector('#distritoda_dg'); 
const anexoda_dg = document.querySelector('#anexoda_dg');
const referenciadomicilio_dg = document.querySelector('#referenciadomicilio_dg');
const lugarnacimiento_dg = document.querySelector('#lugarnacimiento_dg');
const departamentoln_dg = document.querySelector('#departamentoln_dg')
const provincialn_dg = document.querySelector('#provincialn_dg')
const distritoln_dg = document.querySelector('#distritoln_dg');
const anexoln_dg = document.querySelector('#anexoln_dg');
const estadocivil_dg = document.querySelector('#estadocivil_dg');
const numerohijos_dg = document.querySelector('#numerohijos_dg');

const btn_nuevo_dg = document.querySelector('#btn-nuevo-dg');
const btn_save_dg = document.querySelector('#btn-save-dg');

document.addEventListener('DOMContentLoaded', function () {

  // cargarFormulario();
  validarCampos();

  // LISTAR FICHAS SOCIOECONOMICAS-ADMINISTRADOR INICIO
  $('#table_listaestudiantesfs').DataTable({
    ajax: {
      url: ruta + 'controllers/fichasocioeconomicaController.php?option=listar',
      dataSrc: ''
    },
    columns: [
      { data: 'IdAlumno' },
      { data: 'Nombre' },
      { data: 'DNI' },
      { data: 'result' },
      { data: 'accion' }
    ],
    language: {
      url: 'https://cdn.datatables.net/plug-ins/1.13.1/i18n/es-ES.json'
    },
    "order": [[0, 'desc']]
  });
  // LISTAR FICHAS SOCIOECONOMICAS-ADMINISTRADOR FIN
  
  // LISTAR FICHAS SOCIOECONOMICAS-ALUMNO INICIO
  $('#table_listafichaalumno').DataTable({
    ajax: {
      url: ruta + 'controllers/fichasocioeconomicaController.php?option=listaralumno',
      dataSrc: ''
    },
    columns: [
      { data: 'IdAlumno' },
      { data: 'Nombre' },
      { data: 'DNI' },
      { data: 'accion' }
    ],
    language: {
      url: 'https://cdn.datatables.net/plug-ins/1.13.1/i18n/es-ES.json'
    },
    "order": [[0, 'desc']]
  });
  // LISTAR FICHAS SOCIOECONOMICAS-ALUMNO FIN

  // Cargar Listas Desolegables de Departamento
  cargarDepartamentoda();
  cargarDepartamentoln();

  //==== DEPARTAMENTO, PROVINCIA, DISTRITO DE DOMICILIO ACTUAL===//
  // Funcion para cargar Provincia de Domicilio Actual-Inicio
  $('select[name="departamentoda_dg"]').on('change', function () {
    var id = $(this).val();
    var options = '<option value="">Seleccionar():</option>';
    if (id === '') {
        provinciada_dg.innerHTML = options;
        return false;
    }
    axios.get(ruta + 'controllers/provinciaController.php?option=datos&iddep='+id)
    .then(function (response) {
      const info = response.data;
      let html = '<option value="">Seleccionar():</option>';
      info.forEach(provin => {
        html += '<option value="' + provin.IdProvincia + '">' + provin.Nombre + '</option>';
      });
      // alert(html);
      provinciada_dg.innerHTML = html;
    })
    .catch(function (error) {
      console.log(error);
    });
    
  }); 
  // Funcion para cargar Provincia de Domicilio Actual-Fin

  // Funcion para cargar Distrito de Domicilio Actual-Inicio
  $('select[name="provinciada_dg"]').on('change', function () {
    var id = $(this).val();
    var options = '<option value="">Seleccionar():</option>';
    if (id === '') {
        distritoda_dg.innerHTML = options;
        return false;
    }
    axios.get(ruta + 'controllers/distritoController.php?option=datos&idpro='+id)
    .then(function (response) {
      const info = response.data;
      let html = '<option value="">Seleccionar():</option>';
      info.forEach(distr => {
        html += '<option value="' + distr.IdDistrito + '">' + distr.Nombre + '</option>';
      });
      distritoda_dg.innerHTML = html;
    })
    .catch(function (error) {
      console.log(error);
    });
    
  }); 
  // Funcion para cargar Distrito de Domicilio Actual-Fin

  //==== DEPARTAMENTO, PROVINCIA, DISTRITO DE LUGAR NACIMIENTO ===//
  // Funcion para cargar Provincia de Lugar Nacimiento-Inicio
  $('select[name="departamentoln_dg"]').on('change', function () {
    var id = $(this).val();
    var options = '<option value="">Seleccionar():</option>';
    if (id === '') {
        // select_provinciada.html(options);
        provincialn_dg.innerHTML = options;
        return false;
    }
    axios.get(ruta + 'controllers/provinciaController.php?option=datos&iddep='+id)
    .then(function (response) {
      const info = response.data;
      let html = '<option value="">Seleccionar():</option>';
      info.forEach(provin => {
        html += '<option value="' + provin.IdProvincia + '">' + provin.Nombre + '</option>';
      });
      // alert(html);
      provincialn_dg.innerHTML = html;
    })
    .catch(function (error) {
      console.log(error);
    });
    
  }); 
  // Funcion para cargar Provincia de Lugar Nacimiento-Fin

  // Funcion para cargar Distrito de Lugar Nacimiento-Inicio
  $('select[name="provincialn_dg"]').on('change', function () {
    var id = $(this).val();
    var options = '<option value="">Seleccionar():</option>';
    if (id === '') {
        distritoln_dg.innerHTML = options;
        return false;
    }
    axios.get(ruta + 'controllers/distritoController.php?option=datos&idpro='+id)
    .then(function (response) {
      const info = response.data;
      let html = '<option value="">Seleccionar():</option>';
      info.forEach(distr => {
        html += '<option value="' + distr.IdDistrito + '">' + distr.Nombre + '</option>';
      });
      distritoln_dg.innerHTML = html;
    })
    .catch(function (error) {
      console.log(error);
    });
    
  }); 
  // Funcion para cargar Distrito de Lugar Nacimiento-Fin
  
  // GUARDAR INFO ALUMNO
  frm_infoalumno.onsubmit = function (e) {
      e.preventDefault();
      
      if (nombres_dg.value == '' || apellidopaterno_dg.value == '' || apellidomaterno_dg.value == ''
      || edad_dg.value == '' || genero_dg.value == '' || dni_dg.value == '' || telefonocelular_dg.value == '' || correo_dg.value == ''
      || domicilioactual_dg.value == '' || distritoda_dg.value == '' || anexoda_dg.value == '' || referenciadomicilio_dg.value == '' || lugarnacimiento_dg.value == '' || distritoln_dg.value == '' 
      || anexoln_dg.value == '' || estadocivil_dg.value == '' || numerohijos_dg.value == '') {
        message('error', 'TODO LOS CAMPOS CON * SON REQUERIDOS')
      } else {

        const parameters = new FormData(frm_infoalumno);
        axios.post(ruta + 'controllers/datosgeneralesController.php?option=save', parameters)
          .then(function (response) {
            const info = response.data;
            message(info.tipo, info.mensaje);
            if (info.tipo == 'success') {
              setTimeout(() => {
                window.location.reload();
              }, 1500);
            }
          })
          .catch(function (error) {
            console.log(error);
          });
      }
  }

  // LIMPIAR FORMULARIO DE DATOS GENERALES
  btn_nuevo_dg.onclick = function () {
    frm_infoalumno.reset();
    id_alumno_dg.value = '';
    btn_save_dg.innerHTML = 'Guardar';
    nombres_dg.focus();
  }

})

// Cargar Departamento Domicilio Actual-Inicio
function cargarDepartamentoda() {
    axios.get(ruta + 'controllers/departamentoController.php?option=datos&item=departamento')
      .then(function (response) {
        const info = response.data;
        let html = '<option value="">Seleccionar():</option>';
        info.forEach(departament => {
          html += `<option value="${departament.IdDepartamento}">${departament.Nombre}</option>`;
        });
        departamentoda_dg.innerHTML = html;
        
      })
      .catch(function (error) {
        console.log(error);
      });
}
// Cargar Departamento Domicilio Actual-Fin

// Cargar Departamento Lugar Nacimiento-Inicio
function cargarDepartamentoln() {
  axios.get(ruta + 'controllers/departamentoController.php?option=datos&item=departamento')
    .then(function (response) {
      const info = response.data;
      let html = '<option value="">Seleccionar():</option>';
      info.forEach(departament => {
        html += `<option value="${departament.IdDepartamento}">${departament.Nombre}</option>`;
      });
      departamentoln_dg.innerHTML = html;
    })
    .catch(function (error) {
      console.log(error);
    });
}
// Cargar Departamento Lugar Nacimiento-Fin

function cargarFormulario() {
  document.getElementById("formdatosgenerales").style.display = "block";
  document.getElementById("formaspectoacademico").style.display = "none";
  document.getElementById("forminfofamilia").style.display = "none";
  document.getElementById("forminfoeconomica").style.display = "none";
  document.getElementById("forminfovivienda").style.display = "none";
  document.getElementById("forminfoalimentacion").style.display = "none";
  document.getElementById("forminfosalud").style.display = "none";
  document.getElementById("forminfopsicosocial").style.display = "none";
}

function validarCampos(){
  // Para validar Numero de DNi
  $('input[name="dni_dg"]').bind('keypress', function(event) {
      var regex = new RegExp("^[0-9]+$");
      var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
      if (!regex.test(key)) {
          event.preventDefault();
          return false;
      }
  });

  // Para validar Edad
  $('input[name="edad_dg"]').bind('keypress', function(event) {
      var regex = new RegExp("^[0-9]+$");
      var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
      if (!regex.test(key)) {
          event.preventDefault();
          return false;
      }
  });


  // Para validar Numero de celular
  $('input[name="telefonocelular_dg"]').bind('keypress', function(event) {
      var regex = new RegExp("^[0-9]+$");
      var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
      if (!regex.test(key)) {
        event.preventDefault();
        return false;
      }
  });

  // Para validar Numero de hijos
  $('input[name="numerohijos_dg"]').bind('keypress', function(event) {
    var regex = new RegExp("^[0-9]+$");
    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
    if (!regex.test(key)) {
      event.preventDefault();
      return false;
    }
});
}
