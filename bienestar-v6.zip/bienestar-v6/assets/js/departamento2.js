const frm_d = document.querySelector('#frmDepartamento');
const nombre_d = document.querySelector('#nombre_d');
const id_departamento_d = document.querySelector('#id_departamento_d');

const btn_nuevo_d = document.querySelector('#btn-nuevo-d');
const btn_save_d = document.querySelector('#btn-save-d');

document.addEventListener('DOMContentLoaded', function () {
  // LISTAR
  $('#tabla_departamento').DataTable({
    ajax: {
      url: ruta + 'controllers/departamentoController.php?option=listar',
      dataSrc: ''
    },
    columns: [
      { data: 'IdDepartamento' },
      { data: 'Nombre' },
      { data: 'accion' }
    ],
    language: {
      url: 'https://cdn.datatables.net/plug-ins/1.13.1/i18n/es-ES.json'
    },
    "order": [[0, 'desc']]
  });

  // GUARDAR
  $('#frmDepartamento').on('submit', function (e) {
    e.preventDefault();
  
    if (nombre_d.value == '') {
      message('error', 'TODO LOS CAMPOS CON * SON REQUERIDOS')
    } else {
      const frmData_d = new FormData(frm_d);
      axios.post(ruta + 'controllers/departamentoController.php?option=save', frmData_d)
        .then(function (response) {
          const info = response.data;
          message(info.tipo, info.mensaje);
          if (info.tipo == 'success') {
            setTimeout(() => {
              window.location.reload();
            }, 1500);
          }
        })
        .catch(function (error) {
          console.log(error);
        });
    }
  });

  // LIMPIAR FORMULARIO
  btn_nuevo_d.onclick = function () {
    frm_d.reset();
    id_departamento_d.value = '';
    btn_save_d.innerHTML = 'Guardar';
    nombre_d.focus();
  }
})

// EDITAR
function edit(id) {
  axios.get(ruta + 'controllers/departamentoController.php?option=edit&IdDepartamento=' + id)
    .then(function (response) {
      const info = response.data;
      nombre_d.value = info.Nombre;
      id_departamento_d.value = info.IdDepartamento;
      btn_save_d.innerHTML = 'Actualizar';
      nombre_d.focus();
    })
    .catch(function (error) {
      console.log(error);
    });
}

// ELIMINAR
function eliminar(id) {
  Snackbar.show({
    text: 'Esta seguro de eliminar',
    width: '475px',
    actionText: 'Si eliminar',
    backgroundColor: '#FF0303',
    onActionClick: function (element) {
      axios.get(ruta + 'controllers/departamentoController.php?option=delete&IdDepartamento=' + id)
        .then(function (response) {
          const info = response.data;
          message(info.tipo, info.mensaje);
          if (info.tipo == 'success') {
            setTimeout(() => {
              window.location.reload();
            }, 1500);
          }
        })
        .catch(function (error) {
          console.log(error);
        });
    }
  });

}