// INFO PSICOSOCIAL
const economico_ap = document.querySelector('#economico_ap');
const alimentacion_ap = document.querySelector('#alimentacion_ap');
const vivienda_ap = document.querySelector('#vivienda_ap');
const transporte_ap = document.querySelector('#transporte_ap');
const familiar_ap = document.querySelector('#familiar_ap');
const psicologico_ap = document.querySelector('#psicologico_ap');

const consumealcohol_ap = document.querySelector('#consumealcohol_ap');
const parentesco_ap = document.querySelector('#parentesco_ap');
const existeviolencia_ap = document.querySelector('#existeviolencia_ap');
const especifique_ap = document.querySelector('#especifique_ap');

const btn_nuevo_ap = document.querySelector('#btn-nuevo-ap');
const btn_save_ap = document.querySelector('#btn-save-ap');

const frmInfoSocial = document.querySelector('#frmInfoSocial');
const id_alumno_ap = document.querySelector('#id_alumno_ap');

document.addEventListener('DOMContentLoaded', function () {
      
    // Cargar Listas Desplegables de Carrera
    cargarCarrera();
    
    // GUARDAR INFO VIVIENDA
    frmInfoSocial.onsubmit = function (e) {
        e.preventDefault();
      
        if (economico_ap.value == '' || alimentacion_ap.value == '' || vivienda_ap.value == ''
        || transporte_ap.value == '' || familiar_ap.value == '' || psicologico_ap.value == '' 
        || consumealcohol_ap.value == '' || parentesco_ap.value == '' || existeviolencia_ap.value == ''
        || especifique_ap.value == '') {
          message('error', 'TODO LOS CAMPOS CON * SON REQUERIDOS')
        } else {
        // alert('TODO OK');
          const frm_ap = new FormData(frmInfoSocial);
          axios.post(ruta + 'controllers/infopsicosocialController.php?option=save', frm_ap)
            .then(function (response) {
              const info = response.data;
              message(info.tipo, info.mensaje);
              if (info.tipo == 'success') {
                setTimeout(() => {
                  window.location.reload();
                }, 1500);
              }
            })
            .catch(function (error) {
              console.log(error);
            });
        }
    }

    // LIMPIAR FORMULARIO DE INFO ACADEMICA
    btn_nuevo_ap.onclick = function () {
      frmInfoSocial.reset();
      id_alumno_ap.value = '';
      btn_save_ap.innerHTML = 'Guardar';
      economico_ap.focus();
    }
  
  })