// ASPECTO FAMILIAR
const frmInfoFamilia = document.querySelector('#frmInfoFamilia');
const padres_af = document.querySelector('#padres_af');
const orfandad_af = document.querySelector('#orfandad_af');
const otrosespecifique_af = document.querySelector('#otrosespecifique_af');
const numerodehermanos_af = document.querySelector('#numerodehermanos_af');
const btn_nuevo_af = document.querySelector('#btn-nuevo-af');
const btn_save_af = document.querySelector('#btn-save-af');

const id_alumno_af = document.querySelector('#id_alumno_af');

const form_AgregarFamiliar = document.querySelector('#formAgregarFamiliar');
const btn_agregar_familiar = document.querySelector('#btn-agregar-ifamiliar');

document.addEventListener('DOMContentLoaded', function () {
    // LISTAR ESTRUCTURA FAMILIAR
    $('#table_estructurafamiliar_af').DataTable({

      search: false,
      searching: false,
      paging: false,
      bInfo: false,

      ajax: {
        url: ruta + 'controllers/infofamiliarController.php?option=listarfamiliar',
        dataSrc: ''
      },
      columns: [
        { data: 'ApellidosNombres' },
        { data: 'Edad' },
        { data: 'Sexo' },
        { data: 'Parentesco' },
        { data: 'Celular' },
        { data: 'EstadoCivil' },
        { data: 'GradoInstruccion' },
        { data: 'Ocupacion' },
        { data: 'IngresoSemanal' }
      ],
      language: {
        url: 'https://cdn.datatables.net/plug-ins/1.13.1/i18n/es-ES.json'
      },
      "order": [[0, 'desc']]
    });
      
    // GUARDAR INFO FAMILIAR
    frmInfoFamilia.onsubmit = function (e) {
        e.preventDefault();
      
        if (padres_af.value == '' || orfandad_af.value == '' || otrosespecifique_af.value == '' || numerodehermanos_af.value == '') {
          message('error', 'TODO LOS CAMPOS CON * SON REQUERIDOS');
        } else {
            // alert(viveactualemte_af);
          
          const frm_af = new FormData(frmInfoFamilia);
          axios.post(ruta + 'controllers/infofamiliarController.php?option=save', frm_af)
            .then(function (response) {
              const info = response.data;
              message(info.tipo, info.mensaje);
              if (info.tipo == 'success') {
                setTimeout(() => {
                  window.location.reload();
                }, 1500);
              }
            })
            .catch(function (error) {
              console.log(error);
            });
            
        }
    }

    // LIMPIAR FORMULARIO DE DATOS GENERALES
    btn_nuevo_af.onclick = function () {
      frmInfoFamilia.reset();
      id_alumno_af.value = '';
      btn_save_af.innerHTML = 'Guardar';
      padres_af.focus();
    }

    // ABRIR MODAL PARA ABRIR MODAL FAMILIAR
    btn_agregar_familiar.onclick = function () {
      $('#modalEstructuraFamiliar').modal('show');
      $('#formAgregarFamiliar')[0].reset()
    }

    // BOTON PARA GUARDAR MODAL ESTRUCTURA FAMILIAR
    form_AgregarFamiliar.onsubmit = function (e) {
      e.preventDefault();

      const nombres_af_m = document.querySelector('#nombres_af_m');
      const apepat_af_m = document.querySelector('#apepat_af_m');
      const apemat_af_m = document.querySelector('#apemat_af_m');
      const edad_af_m = document.querySelector('#edad_af_m');
      const sexo_af_m = document.querySelector('#sexo_af_m');
      const parentesco_af_m = document.querySelector('#parentesco_af_m');
      const numcel_af_m = document.querySelector('#numcel_af_m');
      const estadocivil_af_m = document.querySelector('#estadocivil_af_m');
      const gradoins_af_m = document.querySelector('#gradoins_af_m');
      const ocupacion_af_m = document.querySelector('#ocupacion_af_m');
      const ingrsemanal_af_m = document.querySelector('#ingrsemanal_af_m');
      
      if (nombres_af_m.value == '' || apepat_af_m.value == '' || apemat_af_m.value == ''
      || edad_af_m.value == '' || sexo_af_m.value == '' || parentesco_af_m.value == '' || numcel_af_m.value == '' || estadocivil_af_m.value == ''
      || gradoins_af_m.value == '' || ocupacion_af_m.value == '' || ingrsemanal_af_m.value == '') {
        message('error', 'TODO LOS CAMPOS CON * SON REQUERIDOS');
      } else {
        const frm_afm = new FormData(form_AgregarFamiliar);
        axios.post(ruta + 'controllers/infofamiliarController.php?option=savefamilia', frm_afm)
          .then(function (response) {
            const info = response.data;
            message(info.tipo, info.mensaje);
            if (info.tipo == 'success') {
              setTimeout(() => {
                window.location.reload();
              }, 1500);
            }
          })
          .catch(function (error) {
            console.log(error);
          }); 
      }

  }

  
})
