// ASPECTO ALIMENTACION
const cocinacasa_ia = document.querySelector('#cocinacasa_ia');
const detalle_ia = document.querySelector('#detalle_ia');
const tipococina_ia = document.querySelector('#tipococina_ia');
const comedoruniv_ia = document.querySelector('#comedoruniv_ia');

const btn_nuevo_ia = document.querySelector('#btn-nuevo-ia');
const btn_save_ia = document.querySelector('#btn-save-ia');

const frmInfoAlimentacion = document.querySelector('#frmInfoAlimentacion');
const id_alumno_ia = document.querySelector('#id_alumno_ia');

document.addEventListener('DOMContentLoaded', function () {
       
    // GUARDAR INFO ALIMENTACION
    frmInfoAlimentacion.onsubmit = function (e) {
        e.preventDefault();
      
        if (cocinacasa_ia.value == '' || detalle_ia.value == '' || tipococina_ia.value == ''
        || comedoruniv_ia.value == '') {
          message('error', 'TODO LOS CAMPOS CON * SON REQUERIDOS')
        } else {
        // alert('TODO OK');
          const frm_ia = new FormData(frmInfoAlimentacion);
          axios.post(ruta + 'controllers/infoalimentacionController.php?option=save', frm_ia)
            .then(function (response) {
              const info = response.data;
              message(info.tipo, info.mensaje);
              if (info.tipo == 'success') {
                setTimeout(() => {
                  window.location.reload();
                }, 1500);
              }
            })
            .catch(function (error) {
              console.log(error);
            });
        }
    }

    // LIMPIAR FORMULARIO DE INFO ALIMENTACION
    btn_nuevo_ia.onclick = function () {
        frmInfoAlimentacion.reset();
        id_alumno_ia.value = '';
        btn_save_ia.innerHTML = 'Guardar';
        cocinacasa_ia.focus();
      }
  
  })