// INFO VIVIENDA
const viveen_iv = document.querySelector('#viveen_iv');
const otrosviveen_iv = document.querySelector('#otrosviveen_iv');
const material_iv = document.querySelector('#material_iv');
const otrosmat_iv = document.querySelector('#otrosmat_iv');

const estado_iv = document.querySelector('#estado_iv');

const btn_nuevo_iv = document.querySelector('#btn-nuevo-iv');
const btn_save_iv = document.querySelector('#btn-save-iv');

const frmInfoVivienda = document.querySelector('#frmInfoVivienda');
const id_alumno_iv = document.querySelector('#id_alumno_iv');

document.addEventListener('DOMContentLoaded', function () {
          
    // GUARDAR INFO VIVIENDA
    frmInfoVivienda.onsubmit = function (e) {
        e.preventDefault();
      
        if (viveen_iv.value == '' || material_iv.value == '' || estado_iv.value == '') {
          message('error', 'TODO LOS CAMPOS CON * SON REQUERIDOS')
        } else {
        // alert('TODO OK');
          const frm_iv = new FormData(frmInfoVivienda);
          axios.post(ruta + 'controllers/infoviviendaController.php?option=save', frm_iv)
            .then(function (response) {
              const info = response.data;
              message(info.tipo, info.mensaje);
              if (info.tipo == 'success') {
                setTimeout(() => {
                  window.location.reload();
                }, 1500);
              }
            })
            .catch(function (error) {
              console.log(error);
            });
        }
    }

    // LIMPIAR FORMULARIO DE INFO ACADEMICA
    btn_nuevo_iv.onclick = function () {
      frmInfoVivienda.reset();
      id_alumno_iv.value = '';
      btn_save_iv.innerHTML = 'Guardar';
      viveen_iv.focus();
    }
  
  })


