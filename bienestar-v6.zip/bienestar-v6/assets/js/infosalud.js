// ASPECTO SALUD
const seguro_is = document.querySelector('#seguro_is');
const tiposeguro_is = document.querySelector('#tiposeguro_is');
const parientecontacto_is = document.querySelector('#parientecontacto_is');
const numerocontacto_is = document.querySelector('#numerocontacto_is');

const usted_is_ps = document.querySelector('#usted_is_ps');
const usteddetalle_is_ps = document.querySelector('#usteddetalle_is_ps');
const padre_is_ps = document.querySelector('#padre_is_ps');
const padredetalle_is_ps = document.querySelector('#padredetalle_is_ps');
const madre_is_ps = document.querySelector('#madre_is_ps');
const madredetalle_is_ps = document.querySelector('#madredetalle_is_ps');
const hermano_is_ps = document.querySelector('#hermano_is_ps');
const hermanodetalle_is_ps = document.querySelector('#hermanodetalle_is_ps');
const otro_is_ps = document.querySelector('#otro_is_ps');
const otrodetalle_is_ps = document.querySelector('#otrodetalle_is_ps');

const usted_is_d = document.querySelector('#usted_is_d');
const usteddetalle_is_d = document.querySelector('#usteddetalle_is_d');
const padre_is_d = document.querySelector('#padre_is_d');
const padredetalle_is_d = document.querySelector('#padredetalle_is_d');
const madre_is_d = document.querySelector('#madre_is_d');
const madredetalle_is_d = document.querySelector('#madredetalle_is_d');
const hermano_is_d = document.querySelector('#hermano_is_d');
const hermanodetalle_is_d = document.querySelector('#hermanodetalle_is_d');
const otro_is_d = document.querySelector('#otro_is_d');
const otrodetalle_is_d = document.querySelector('#otrodetalle_is_d');

const btn_nuevo_is = document.querySelector('#btn-nuevo-is');
const btn_save_is = document.querySelector('#btn-save-is');

const frmInfoSalud = document.querySelector('#frmInfoSalud');
const id_alumno_is = document.querySelector('#id_alumno_is');

document.addEventListener('DOMContentLoaded', function () {
      
    // Cargar Listas Desplegables de Carrera
    cargarCarrera();
    
    // GUARDAR INFO SALUD
    frmInfoSalud.onsubmit = function (e) {
        e.preventDefault();
      
        if (seguro_is.value == '' || tiposeguro_is.value == '' || parientecontacto_is.value == ''
        || numerocontacto_is.value == '' || usted_is_ps.value == '' || usteddetalle_is_ps.value == '' 
        || padre_is_ps.value == '' || padredetalle_is_ps.value == '' || madre_is_ps.value == '' 
        || madredetalle_is_ps.value == '' || hermano_is_ps.value == '' || hermanodetalle_is_ps.value == '' 
        || otro_is_ps.value == '' || otrodetalle_is_ps.value == '' || usted_is_d.value == '' 
        || usteddetalle_is_d.value == '' || padre_is_d.value == '' || padredetalle_is_d.value == '' 
        || madre_is_d.value == '' || madredetalle_is_d.value == '' || hermano_is_d.value == '' 
        || hermanodetalle_is_d.value == ''|| otro_is_d.value == '' || otrodetalle_is_d.value == '' ) {
          message('error', 'TODO LOS CAMPOS CON * SON REQUERIDOS')
        } else {
        // alert('TODO OK');
          const frm_is = new FormData(frmInfoSalud);
          axios.post(ruta + 'controllers/infosaludController.php?option=save', frm_is)
            .then(function (response) {
              const info = response.data;
              message(info.tipo, info.mensaje);
              if (info.tipo == 'success') {
                setTimeout(() => {
                  window.location.reload();
                }, 1500);
              }
            })
            .catch(function (error) {
              console.log(error);
            });
        }
    }

    // LIMPIAR FORMULARIO DE INFO ACADEMICA
    btn_nuevo_is.onclick = function () {
      frmInfoSalud.reset();
      id_alumno_is.value = '';
      btn_save_is.innerHTML = 'Guardar';
      seguro_is.focus();
    }
  
  })