const frm = document.querySelector('#frmLogin');
const usu = document.querySelector('#usuario');
const cont = document.querySelector('#contrasena');

document.addEventListener('DOMContentLoaded', function () {
    var working = false;
    // Boton Acceder Sistema - Inicio
    frm.onsubmit = function (e) {
        e.preventDefault();

        if (usu.value == '' || cont.value == '') {
            message('error', 'TODO LOS CAMPOS CON * SON REQUERIDOS');
        } else {
            if (working) return;
            working = true;
            var $this = $(this),
                $state = $this.find('button > .state');
            $this.addClass('loading');
            $state.html('Authenticating');

            axios.post(ruta + 'controllers/usuarioController.php?option=acceso', {
                usu: usu.value,
                cont: cont.value
            })
            .then(function (response) {

                const info = response.data;
                if (info.tipo == 'Administrador') {
                    setTimeout(() => {
                        $this.addClass('ok');
                        $state.html('Bienvenido Administrador!'); $this.addClass('ok');
                        $state.html('Bienvenido Administrador!');
                        setTimeout(() => {
                            window.location = ruta + 'plantilla.php';
                        }, 2000);

                    }, 3000);

                }
                else if (info.tipo == 'Alumno') {
                    setTimeout(() => {
                        $this.addClass('ok');
                        $state.html('Bienvenido Estudiante!'); $this.addClass('ok');
                        $state.html('Bienvenido Estudiante!!');
                        setTimeout(() => {
                            window.location = ruta + 'plantilla.php';
                        }, 2000);

                    }, 3000);

                } 
                else {
                    setTimeout(function () {
                        $state.html('Login');
                        $this.removeClass('ok loading');
                        working = false;
                        message(info.tipo, info.mensaje);
                    }, 2000);
                }

            })
            .catch(function (error) {
                console.log(error);
            });

        }

    }
    // Boton Acceder Sistema - Fin

})

function message(tipo, mensaje) {
    Snackbar.show({
        text: mensaje,
        pos: 'top-right',
        backgroundColor: tipo == 'success' ? '#079F00' : '#FF0303',
        actionText: 'Cerrar'
    });
}