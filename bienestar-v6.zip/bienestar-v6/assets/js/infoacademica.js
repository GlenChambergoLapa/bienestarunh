// ASPECTO ACADEMICO
const carrera_aa = document.querySelector('#carrera_aa');
const codigomatricula_aa = document.querySelector('#codigomatricula_aa');
const ciclo_aa = document.querySelector('#ciclo_aa');
const segundacarrera_aa = document.querySelector('#segundacarrera_aa');
const promedioponderado_aa = document.querySelector('#promedioponderado_aa');
const numcursosdesaprobados_aa = document.querySelector('#numcursosdesaprobados_aa');
const numcursoacargo_aa = document.querySelector('#numcursoacargo_aa');
const modalidadingreso_aa = document.querySelector('#modalidadingreso_aa');
const abandonoestudios_aa = document.querySelector('#abandonoestudios_aa');
const motivo_aa = document.querySelector('#motivo_aa');

const btn_nuevo_aa = document.querySelector('#btn-nuevo-aa');
const btn_save_aa = document.querySelector('#btn-save-aa');

const frmInfoAcademica = document.querySelector('#frmInfoAcademica');
const id_alumno_aa = document.querySelector('#id_alumno_aa');

document.addEventListener('DOMContentLoaded', function () {
      
    // Cargar Listas Desplegables de Carrera
    cargarCarrera();
    
    // GUARDAR INFO ACADEMICA
    frmInfoAcademica.onsubmit = function (e) {
        e.preventDefault();
      
        if (carrera_aa.value == '' || codigomatricula_aa.value == '' || ciclo_aa.value == ''
        || segundacarrera_aa.value == '' || promedioponderado_aa.value == '' || numcursosdesaprobados_aa.value == ''
        || numcursoacargo_aa.value == '' || modalidadingreso_aa.value == '' || abandonoestudios_aa.value == '' || motivo_aa.value == '') {
          message('error', 'TODO LOS CAMPOS CON * SON REQUERIDOS')
        } else {
        // alert('TODO OK');
          const frm_aa = new FormData(frmInfoAcademica);
          axios.post(ruta + 'controllers/infoacademicaController.php?option=save', frm_aa)
            .then(function (response) {
              const info = response.data;
              message(info.tipo, info.mensaje);
              if (info.tipo == 'success') {
                setTimeout(() => {
                  window.location.reload();
                }, 1500);
              }
            })
            .catch(function (error) {
              console.log(error);
            });
        }
    }

    // LIMPIAR FORMULARIO DE INFO ACADEMICA
    btn_nuevo_aa.onclick = function () {
      frmInfoAcademica.reset();
      id_alumno_aa.value = '';
      btn_save_aa.innerHTML = 'Guardar';
      carrera_aa.focus();
    }
  
  })

  // Cargar Facultad, Escuela y Carrera - Inicio
function cargarCarrera() {
    axios.get(ruta + 'controllers/carreraController.php?option=datos&item=carrera')
      .then(function (response) {
        const info = response.data;
        let html = '<option value="">Seleccionar():</option>';
        info.forEach(carr => {
          
          var valorcarrera='/ ' + carr.Carrera;

          if (carr.Carrera == "NA"){
            valorcarrera = "";
          }
          
          html += `<option value="${carr.IdCarrera}">${carr.Filial+"/ "+carr.Facultad+"/ "+carr.Escuela + valorcarrera}</option>`;
        });
        carrera_aa.innerHTML = html;
      })
      .catch(function (error) {
        console.log(error);
      });
  }
  // Cargar Facultad, Escuela y Carrera - Fin