// ASPECTO ECONOMICO
const dependencia_ie = document.querySelector('#dependencia_ie');
const ingresofamsemanal_ie = document.querySelector('#ingresofamsemanal_ie');
const actividadeconomica_ie = document.querySelector('#actividadeconomica_ie');
const especifique_ie = document.querySelector('#especifique_ie');
const ingresosemanal_ie = document.querySelector('#ingresosemanal_ie');
const otrosespecifique_ie = document.querySelector('#otrosespecifique_ie');

const btn_nuevo_ie = document.querySelector('#btn-nuevo-ie');
const btn_save_ie = document.querySelector('#btn-save-ie');

const frmInfoEconomica = document.querySelector('#frmInfoEconomica');
const id_alumno_ie = document.querySelector('#id_alumno_ie');

document.addEventListener('DOMContentLoaded', function () {
          
    // GUARDAR INFO ECONOMICA
    frmInfoEconomica.onsubmit = function (e) {
        e.preventDefault();
      
        if (dependencia_ie.value == '' || ingresofamsemanal_ie.value == '' || actividadeconomica_ie.value == ''
        || especifique_ie.value == '' || ingresosemanal_ie.value == '') {
          message('error', 'TODO LOS CAMPOS CON * SON REQUERIDOS')
        } else {
        // alert('TODO OK');
          const frm_ie = new FormData(frmInfoEconomica);
          axios.post(ruta + 'controllers/infoeconomicaController.php?option=save', frm_ie)
            .then(function (response) {
              const info = response.data;
              message(info.tipo, info.mensaje);
              if (info.tipo == 'success') {
                setTimeout(() => {
                  window.location.reload();
                }, 1500);
              }
            })
            .catch(function (error) {
              console.log(error);
            });
        }
    }

    // LIMPIAR FORMULARIO DE INFO ECONOMICA
    btn_nuevo_ie.onclick = function () {
      frmInfoEconomica.reset();
      id_alumno_ie.value = '';
      btn_save_ie.innerHTML = 'Guardar';
      carrera_ie.focus();
    }
  
  })