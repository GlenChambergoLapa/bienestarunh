const frm = document.querySelector('#frmUser');
const usu = document.querySelector('#usuario');
const perfil = document.querySelector('#perfil');
const estado = document.querySelector('#estado');
const con = document.querySelector('#contrasena');
const id_user = document.querySelector('#id_user');
const btn_nuevo = document.querySelector('#btn-nuevo');
const btn_save = document.querySelector('#btn-save');

// Listar Usuarios
document.addEventListener('DOMContentLoaded', function () {
  $('#table_users').DataTable({
    ajax: {
      url: ruta + 'controllers/usuarioController.php?option=listar',
      dataSrc: ''
    },
    columns: [
      { data: 'IdUsuario' },
      { data: 'perfil' },
      { data: 'usuario' },
      { data: 'estado' },
      { data: 'accion' }
    ],
    language: {
      url: 'https://cdn.datatables.net/plug-ins/1.13.1/i18n/es-ES.json'
    },
    "order": [[0, 'desc']]
  });

  // Guardar Usuario
  frm.onsubmit = function (e) {
    e.preventDefault();
    if (perfil.value == '' || usu.value == ''
      || con.value == ''|| estado.value == '') {
      message('error', 'TODO LOS CAMPOS CON * SON REQUERIDOS')
    } else {
      const frmData = new FormData(frm);
      axios.post(ruta + 'controllers/usuarioController.php?option=save', frmData)
        .then(function (response) {
          const info = response.data;
          message(info.tipo, info.mensaje);
          if (info.tipo == 'success') {
            setTimeout(() => {
              window.location.reload();
            }, 1500);
          }
        })
        .catch(function (error) {
          console.log(error);
        });
    }
  }
  btn_nuevo.onclick = function () {
    frm.reset();
    id_user.value = '';
    btn_save.innerHTML = 'Guardar';
    con.removeAttribute('readonly');
    perfil.focus();
  }

})

function deleteUser(id) {
  Snackbar.show({
    text: 'Esta seguro de eliminar',
    width: '475px',
    actionText: 'Si eliminar',
    backgroundColor: '#FF0303',
    onActionClick: function (element) {
      axios.get(ruta + 'controllers/usuarioController.php?option=delete&id=' + id)
        .then(function (response) {
          const info = response.data;
          message(info.tipo, info.mensaje);
          if (info.tipo == 'success') {
            setTimeout(() => {
              window.location.reload();
            }, 1500);
          }
        })
        .catch(function (error) {
          console.log(error);
        });
    }
  });

}

function editUser(id) {
  axios.get(ruta + 'controllers/usuarioController.php?option=edit&id=' + id)
    .then(function (response) {
      const info = response.data;
      perfil.value = info.perfil;
      usu.value = info.usuario;
      con.value = '*********************';
      con.setAttribute('readonly', 'readonly');
      estado.value = info.estado;
      id_user.value = info.IdUsuario;
      btn_save.innerHTML = 'Actualizar';
      perfil.focus();
    })
    .catch(function (error) {
      console.log(error);
    });
}