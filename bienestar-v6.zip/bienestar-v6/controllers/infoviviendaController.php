<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once '../models/infovivienda.php';
$option = (empty($_GET['option'])) ? '' : $_GET['option'];
$infovivienda = new InfoViviendaModel();
$id_user = $_SESSION['idusuario'];

switch ($option) {
    case 'save':
        $viveen_iv = $_POST['viveen_iv'];
        $otrosviveen_iv = $_POST['otrosviveen_iv'];
        $material_iv = $_POST['material_iv'];
        $otrosmat_iv = $_POST['otrosmat_iv'];
        $estado_iv = $_POST['estado_iv'];

        $id_alumno_iv = $_POST['id_alumno_iv'];

        $datoscheckboxservicio_iv = '';
        $datoscheckboxequipamiento_iv = '';


        if(isset($_POST['servicio_iv'])){
            $datoscheckboxservicio_iv = implode(', ', $_POST['servicio_iv']);
        }
        if(isset($_POST['equipamiento_iv'])){
            $datoscheckboxequipamiento_iv = implode(', ', $_POST['equipamiento_iv']);
        }




        $consul_idalumno = $infovivienda->getIdAlumno($id_user);
        $idalumno_iv = $consul_idalumno['idalumno'];

        // $res = array('tipo' => 'success', 'mensaje' => 'ID: '.$idalumno_aa);
        



        if ($id_alumno_iv == '') {

                $resultinfovivienda = $infovivienda->save($viveen_iv, $otrosviveen_iv, $material_iv, $otrosmat_iv, $estado_iv, $datoscheckboxservicio_iv, $datoscheckboxequipamiento_iv, $idalumno_iv);
                
                if ($resultinfovivienda) {
                    $res = array('tipo' => 'success', 'mensaje' => 'INFO VIVIENDA REGISTRADO');
                } else {
                    $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL AGREGAR INFO VIVIENDA');
                }
                
            } 
            
    

        // else {
        //     $consult = $estudiantes->comprobarCodigo($codigo, $id_estudiante);
        //     if (empty($consult)) {
        //         $result = $estudiantes->update($codigo, $nombre, $apellido, $telefono, $direccion, $carrera, $nivel, $id_estudiante);
        //         if ($result) {
        //             $res = array('tipo' => 'success', 'mensaje' => 'ESTUDIANTE MODIFICADO');
        //         } else {
        //             $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL MODIFICAR');
        //         }
        //     } else {
        //         $res = array('tipo' => 'error', 'mensaje' => 'EL CODIGO YA EXISTE');
        //     }
        // }
        echo json_encode($res);
        break;
    case 'delete':
        $id = $_GET['id'];
        $data = $estudiantes->delete($id);
        if ($data) {
            $res = array('tipo' => 'success', 'mensaje' => 'ESTUDIANTE ELIMINADO');
        } else {
            $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL ELIMINAR');
        }
        echo json_encode($res);
        break;
    case 'edit':
        $id = $_GET['id'];
        $data = $estudiantes->getEstudiante($id);
        echo json_encode($data);
        break;
    case 'datos':
        $item = $_GET['item'];
        $data = $estudiantes->getDatos($item);
        echo json_encode($data);
        break;
    default:
        # code...
        break;
}
