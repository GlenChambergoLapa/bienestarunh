<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once '../models/datosgenerales.php';
$option = (empty($_GET['option'])) ? '' : $_GET['option'];
$datosgenerales = new DatosGeneralesModel();
$id_user = $_SESSION['idusuario'];

switch ($option) {
    case 'save':
        $nombres_dg = $_POST['nombres_dg'];
        $apellidopaterno_dg = $_POST['apellidopaterno_dg'];
        $apellidomaterno_dg = $_POST['apellidomaterno_dg'];
        $fechadenacimiento_dg = $_POST['fechadenacimiento_dg'];
        $edad_dg = $_POST['edad_dg'];
        $genero_dg = $_POST['genero_dg'];
        $dni_dg = $_POST['dni_dg'];
        $telefonocelular_dg = $_POST['telefonocelular_dg'];
        $correo_dg = $_POST['correo_dg'];
        $domicilioactual_dg = $_POST['domicilioactual_dg'];
        $departamentoda_dg = $_POST['departamentoda_dg'];
        $provinciada_dg = $_POST['provinciada_dg'];
        $distritoda_dg = $_POST['distritoda_dg'];
        $anexoda_dg = $_POST['anexoda_dg'];
        $referenciadomicilio_dg = $_POST['referenciadomicilio_dg'];
        $lugarnacimiento_dg = $_POST['lugarnacimiento_dg'];
        $departamentoln_dg = $_POST['departamentoln_dg'];
        $provincialn_dg = $_POST['provincialn_dg'];
        $distritoln_dg = $_POST['distritoln_dg'];
        $anexoln_dg = $_POST['anexoln_dg'];
        $estadocivil_dg = $_POST['estadocivil_dg'];
        $numerohijos_dg = $_POST['numerohijos_dg'];

        $id_alumno_dg = $_POST['id_alumno_dg'];

        if ($id_alumno_dg == '') {
            $consult = $datosgenerales->comprobarDniAlumno($dni_dg, 0);
            if (empty($consult)) {
                $resultdomicilio = $datosgenerales->saveDomicilio($domicilioactual_dg, $referenciadomicilio_dg, $anexoda_dg, $distritoda_dg);
                if ($resultdomicilio) {
                    $resultlugarnacimiento = $datosgenerales->saveLugarNacimiento($lugarnacimiento_dg,$anexoln_dg, $distritoln_dg);
                    if ($resultlugarnacimiento){

                        $consultiddomicilio = $datosgenerales->getIdDomicilio($domicilioactual_dg);
                        $iddomicilio_dg = $consultiddomicilio['IdDomicilio'];

                        $consultidlugarnacimiento = $datosgenerales->getIdNacimiento($lugarnacimiento_dg);
                        $idlugarnacimiento_dg = $consultidlugarnacimiento['IdNacimiento'];
                       
                        $resultinfoalumno = $datosgenerales->save($nombres_dg, $apellidopaterno_dg, $apellidomaterno_dg, $fechadenacimiento_dg, $edad_dg, $genero_dg, $dni_dg, $telefonocelular_dg, $correo_dg, $estadocivil_dg, $numerohijos_dg, $iddomicilio_dg, $idlugarnacimiento_dg, $id_user);
                        
                        if ($resultinfoalumno){
                            $res = array('tipo' => 'success', 'mensaje' => 'INFO ALUMNO REGISTRADO');
                        }else{
                            $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL AGREGAR INFO ALUMNO');
                        }
                    }else{
                        $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL AGREGAR LUGAR DE NACIMIENTO');
                    }
                } else {
                    $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL AGREGAR DOMICILIO');
                }
            } else {
                $res = array('tipo' => 'error', 'mensaje' => 'EL DNI DEL ALUMNO YA EXISTE');
            }
        } 

        // else {
        //     $consult = $estudiantes->comprobarCodigo($codigo, $id_estudiante);
        //     if (empty($consult)) {
        //         $result = $estudiantes->update($codigo, $nombre, $apellido, $telefono, $direccion, $carrera, $nivel, $id_estudiante);
        //         if ($result) {
        //             $res = array('tipo' => 'success', 'mensaje' => 'ESTUDIANTE MODIFICADO');
        //         } else {
        //             $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL MODIFICAR');
        //         }
        //     } else {
        //         $res = array('tipo' => 'error', 'mensaje' => 'EL CODIGO YA EXISTE');
        //     }
        // }
        echo json_encode($res);
        break;

    case 'delete':
        $id = $_GET['id'];
        $data = $estudiantes->delete($id);
        if ($data) {
            $res = array('tipo' => 'success', 'mensaje' => 'ESTUDIANTE ELIMINADO');
        } else {
            $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL ELIMINAR');
        }
        echo json_encode($res);
        break;
    case 'edit':
        $id = $_GET['id'];
        $data = $estudiantes->getEstudiante($id);
        echo json_encode($data);
        break;
    case 'datos':
        $item = $_GET['item'];
        $data = $estudiantes->getDatos($item);
        echo json_encode($data);
        break;
    default:
        # code...
        break;
}
