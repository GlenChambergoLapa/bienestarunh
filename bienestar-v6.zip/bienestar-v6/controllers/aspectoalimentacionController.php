<?php
require_once '../models/aspectoalimentacion.php';
$option = (empty($_GET['option'])) ? '' : $_GET['option'];
$aspectoalimentacion = new AspectoAlimentacionModel();

switch ($option) {
    case 'save':
        $cocinacasa_ia = $_POST['cocinacasa_ia'];
        $detalle_ia = $_POST['detalle_ia'];
        $tipococina_ia = $_POST['tipococina_ia'];
        $comedoruniv_ia = $_POST['comedoruniv_ia'];
        
        $id_alumno_ia = $_POST['id_alumno_ia'];
        $id_alumno_iaia = 1;

        if ($id_alumno_ia == '') {
            $consult = $aspectoalimentacion->comprobarIdAlumno($id_alumno_ia, 0);
            if (empty($consult)) {
                $result = $aspectoalimentacion->save($cocinacasa_ia, $detalle_ia, $tipococina_ia, $comedoruniv_ia, $id_alumno_iaia);
                if ($result) {
                    $res = array('tipo' => 'success', 'mensaje' => 'INFO ALIMENTACION REGISTRADO');
                } else {
                    $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL AGREGAR');
                }
            } else {
                $res = array('tipo' => 'error', 'mensaje' => 'EL ID ALUMNO YA EXISTE');
            }
        } 

        // else {
        //     $consult = $estudiantes->comprobarCodigo($codigo, $id_estudiante);
        //     if (empty($consult)) {
        //         $result = $estudiantes->update($codigo, $nombre, $apellido, $telefono, $direccion, $carrera, $nivel, $id_estudiante);
        //         if ($result) {
        //             $res = array('tipo' => 'success', 'mensaje' => 'ESTUDIANTE MODIFICADO');
        //         } else {
        //             $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL MODIFICAR');
        //         }
        //     } else {
        //         $res = array('tipo' => 'error', 'mensaje' => 'EL CODIGO YA EXISTE');
        //     }
        // }
        echo json_encode($res);
        break;
    case 'delete':
        $id = $_GET['id'];
        $data = $estudiantes->delete($id);
        if ($data) {
            $res = array('tipo' => 'success', 'mensaje' => 'ESTUDIANTE ELIMINADO');
        } else {
            $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL ELIMINAR');
        }
        echo json_encode($res);
        break;
    case 'edit':
        $id = $_GET['id'];
        $data = $estudiantes->getEstudiante($id);
        echo json_encode($data);
        break;
    case 'datos':
        $item = $_GET['item'];
        $data = $estudiantes->getDatos($item);
        echo json_encode($data);
        break;
    default:
        # code...
        break;
}
