<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once '../models/infoacademica.php';
$option = (empty($_GET['option'])) ? '' : $_GET['option'];
$infoacademica = new InfoAcademicaModel();
$id_user = $_SESSION['idusuario'];

switch ($option) {
    case 'save':
        $carrera_aa = $_POST['carrera_aa'];
        $codigomatricula_aa = $_POST['codigomatricula_aa'];
        $ciclo_aa = $_POST['ciclo_aa'];
        $segundacarrera_aa = $_POST['segundacarrera_aa'];
        $promedioponderado_aa = $_POST['promedioponderado_aa'];
        $numcursosdesaprobados_aa = $_POST['numcursosdesaprobados_aa'];
        $numcursoacargo_aa = $_POST['numcursoacargo_aa'];
        $modalidadingreso_aa = $_POST['modalidadingreso_aa'];
        $abandonoestudios_aa = $_POST['abandonoestudios_aa'];
        $motivo_aa = $_POST['motivo_aa'];

        $id_alumno_aa = $_POST['id_alumno_aa'];

        $consul_idalumno = $infoacademica->getIdAlumno($id_user);
        $idalumno_aa = $consul_idalumno['idalumno'];

        // $res = array('tipo' => 'success', 'mensaje' => 'ID: '.$idalumno_aa);

        if ($id_alumno_aa == '') {
            $consult = $infoacademica->comprobarCodigoMatricula($codigomatricula_aa, 0);
            if (empty($consult)) {

                $resultinfoacademica = $infoacademica->save($codigomatricula_aa, $ciclo_aa, $segundacarrera_aa, $promedioponderado_aa, $numcursosdesaprobados_aa, $numcursoacargo_aa, $modalidadingreso_aa, $abandonoestudios_aa, $motivo_aa, $idalumno_aa, $carrera_aa);
                
                if ($resultinfoacademica) {
                    $res = array('tipo' => 'success', 'mensaje' => 'INFO ACADEMICA REGISTRADO');
                } else {
                    $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL AGREGAR INFO ACADEMICA');
                }
                
            } else {
                $res = array('tipo' => 'error', 'mensaje' => 'EL CODIGO DE MATRICULA DEL ALUMNO YA EXISTE');
            }
        } 

        // else {
        //     $consult = $estudiantes->comprobarCodigo($codigo, $id_estudiante);
        //     if (empty($consult)) {
        //         $result = $estudiantes->update($codigo, $nombre, $apellido, $telefono, $direccion, $carrera, $nivel, $id_estudiante);
        //         if ($result) {
        //             $res = array('tipo' => 'success', 'mensaje' => 'ESTUDIANTE MODIFICADO');
        //         } else {
        //             $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL MODIFICAR');
        //         }
        //     } else {
        //         $res = array('tipo' => 'error', 'mensaje' => 'EL CODIGO YA EXISTE');
        //     }
        // }
        echo json_encode($res);
        break;
    case 'delete':
        $id = $_GET['id'];
        $data = $estudiantes->delete($id);
        if ($data) {
            $res = array('tipo' => 'success', 'mensaje' => 'ESTUDIANTE ELIMINADO');
        } else {
            $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL ELIMINAR');
        }
        echo json_encode($res);
        break;
    case 'edit':
        $id = $_GET['id'];
        $data = $estudiantes->getEstudiante($id);
        echo json_encode($data);
        break;
    case 'datos':
        $item = $_GET['item'];
        $data = $estudiantes->getDatos($item);
        echo json_encode($data);
        break;
    default:
        # code...
        break;
}
