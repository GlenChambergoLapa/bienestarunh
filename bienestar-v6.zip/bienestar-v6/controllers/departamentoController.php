<?php
require_once '../models/departamento.php';
$option = (empty($_GET['option'])) ? '' : $_GET['option'];
$departamento = new DepartamentoModel();
switch ($option) {
    case 'listar':
        $data = $departamento->getDepartamentos();
        for ($i = 0; $i < count($data); $i++) {
            $data[$i]['accion'] = '<div class="d-flex">
                <a class="btn btn-danger btn-sm" onclick="eliminar(' . $data[$i]['IdDepartamento'] . ')"><i class="fas fa-eraser"></i></a>
                <a class="btn btn-primary btn-sm" onclick="edit(' . $data[$i]['IdDepartamento'] . ')"><i class="fas fa-edit"></i></a>
            </div>';
        }
        echo json_encode($data);
        break;
    case 'save':
        $nombre_d = $_POST['nombre_d'];
        $id_departamento_d = $_POST['id_departamento_d'];

        if ($id_departamento_d == '') {
            $consult = $departamento->comprobarDepartamento($nombre_d, 0);
            if (empty($consult)) {
                $result = $departamento->save($nombre_d);
                if ($result) {
                    $res = array('tipo' => 'success', 'mensaje' => 'DEPARTAMENTO REGISTRADO');
                } else {
                    $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL AGREGAR');
                }
            } else {
                $res = array('tipo' => 'error', 'mensaje' => 'EL DEPARTAMENTO YA EXISTE');
            }
        } 
        else {
            $consult = $departamento->comprobarDepartamento($nombre_d, $id_departamento_d);
            if (empty($consult)) {
                $result = $departamento->update($nombre_d, $id_departamento_d);
                if ($result) {
                    $res = array('tipo' => 'success', 'mensaje' => 'DEPARTAMENTO MODIFICADO');
                } else {
                    $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL MODIFICAR');
                }
            } else {
                $res = array('tipo' => 'error', 'mensaje' => 'EL DEPARTAMENTO YA EXISTE');
            }
        }
        echo json_encode($res);
        break;    
    case 'edit':
        $id = $_GET['IdDepartamento'];
        $data = $departamento->getDepartamento($id);
        echo json_encode($data);
        break;
    case 'delete':
        $id = $_GET['IdDepartamento'];
        $data = $departamento->delete($id);
        if ($data) {
            $res = array('tipo' => 'success', 'mensaje' => 'DEPARTAMENTO ELIMINADO');
        } else {
            $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL ELIMINAR');
        }
        echo json_encode($res);
        break;
    case 'datos':
        $item = $_GET['item'];
        $data = $departamento->getDatos($item);
        echo json_encode($data);
        break;
    default:
        # code...
        break;
}
