<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once '../models/infosalud.php';
$option = (empty($_GET['option'])) ? '' : $_GET['option'];
$infosalud = new InfoSaludModel();
$id_user = $_SESSION['idusuario'];

switch ($option) {
    case 'save':
        $seguro_is = $_POST['seguro_is'];
        $tiposeguro_is = $_POST['tiposeguro_is'];
        $parientecontacto_is = $_POST['parientecontacto_is'];
        $numerocontacto_is = $_POST['numerocontacto_is'];

        $usted_is_ps = $_POST['usted_is_ps'];
        $usteddetalle_is_ps = $_POST['usteddetalle_is_ps'];
        $padre_is_ps = $_POST['padre_is_ps'];
        $padredetalle_is_ps = $_POST['padredetalle_is_ps'];
        $madre_is_ps = $_POST['madre_is_ps'];
        $madredetalle_is_ps = $_POST['madredetalle_is_ps'];
        $hermano_is_ps = $_POST['hermano_is_ps'];
        $hermanodetalle_is_ps = $_POST['hermanodetalle_is_ps'];
        $otro_is_ps = $_POST['otro_is_ps'];
        $otrodetalle_is_ps = $_POST['otrodetalle_is_ps'];

        $usted_is_d = $_POST['usted_is_d'];
        $usteddetalle_is_d = $_POST['usteddetalle_is_d'];
        $padre_is_d = $_POST['padre_is_d'];
        $padredetalle_is_d = $_POST['padredetalle_is_d'];
        $madre_is_d = $_POST['madre_is_d'];
        $madredetalle_is_d = $_POST['madredetalle_is_d'];
        $hermano_is_d = $_POST['hermano_is_d'];
        $hermanodetalle_is_d = $_POST['hermanodetalle_is_d'];
        $otro_is_d = $_POST['otro_is_d'];
        $otrodetalle_is_d = $_POST['otrodetalle_is_d'];

        $id_alumno_is = $_POST['id_alumno_is'];

        $consul_idalumno = $infosalud->getIdAlumno($id_user);
        $idalumno_is = $consul_idalumno['idalumno'];

        // $res = array('tipo' => 'success', 'mensaje' => 'ID: '.$idalumno_aa);

        if ($id_alumno_is == '') {
            
                $resultinfosalud = $infosalud->save($seguro_is, $tiposeguro_is, $parientecontacto_is, $numerocontacto_is, $usted_is_ps, $usteddetalle_is_ps, $padre_is_ps, $padredetalle_is_ps, $madre_is_ps, $madredetalle_is_ps, $hermano_is_ps, $hermanodetalle_is_ps, $otro_is_ps, $otrodetalle_is_ps, $usted_is_d, $usteddetalle_is_d, $padre_is_d, $padredetalle_is_d, $madre_is_d, $madredetalle_is_d, $hermano_is_d, $hermanodetalle_is_d, $otro_is_d, $otrodetalle_is_d, $idalumno_is);
                
                if ($resultinfosalud) {
                    $res = array('tipo' => 'success', 'mensaje' => 'INFO SALUD REGISTRADO');
                } else {
                    $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL AGREGAR INFO SALUD');
                }
        } 

        // else {
        //     $consult = $estudiantes->comprobarCodigo($codigo, $id_estudiante);
        //     if (empty($consult)) {
        //         $result = $estudiantes->update($codigo, $nombre, $apellido, $telefono, $direccion, $carrera, $nivel, $id_estudiante);
        //         if ($result) {
        //             $res = array('tipo' => 'success', 'mensaje' => 'ESTUDIANTE MODIFICADO');
        //         } else {
        //             $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL MODIFICAR');
        //         }
        //     } else {
        //         $res = array('tipo' => 'error', 'mensaje' => 'EL CODIGO YA EXISTE');
        //     }
        // }
        echo json_encode($res);
        break;
    case 'delete':
        $id = $_GET['id'];
        $data = $estudiantes->delete($id);
        if ($data) {
            $res = array('tipo' => 'success', 'mensaje' => 'ESTUDIANTE ELIMINADO');
        } else {
            $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL ELIMINAR');
        }
        echo json_encode($res);
        break;
    case 'edit':
        $id = $_GET['id'];
        $data = $estudiantes->getEstudiante($id);
        echo json_encode($data);
        break;
    case 'datos':
        $item = $_GET['item'];
        $data = $estudiantes->getDatos($item);
        echo json_encode($data);
        break;
    default:
        # code...
        break;
}
