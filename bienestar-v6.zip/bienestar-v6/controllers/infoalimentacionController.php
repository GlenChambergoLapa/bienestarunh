<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once '../models/infoalimentacion.php';
$option = (empty($_GET['option'])) ? '' : $_GET['option'];
$infoalimentacion = new InfoAlimentacionModel();
$id_user = $_SESSION['idusuario'];

switch ($option) {
    case 'save':
        $cocinacasa_ia = $_POST['cocinacasa_ia'];
        $detalle_ia = $_POST['detalle_ia'];
        $tipococina_ia = $_POST['tipococina_ia'];
        $comedoruniv_ia = $_POST['comedoruniv_ia'];

        $id_alumno_ia = $_POST['id_alumno_ia'];

        $consul_idalumno = $infoalimentacion->getIdAlumno($id_user);
        $idalumno_ia = $consul_idalumno['idalumno'];

        // $res = array('tipo' => 'success', 'mensaje' => 'ID: '.$idalumno_aa);

        if ($id_alumno_ia == '') {
            
                $resultinfoalimentacion = $infoalimentacion->save($cocinacasa_ia, $detalle_ia, $tipococina_ia, $comedoruniv_ia, $idalumno_ia);
                
                if ($resultinfoalimentacion) {
                    $res = array('tipo' => 'success', 'mensaje' => 'INFO ALIMENTACION REGISTRADO');
                } else {
                    $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL AGREGAR INFO ALIMENTACION');
                }
        } 

        // else {
        //     $consult = $estudiantes->comprobarCodigo($codigo, $id_estudiante);
        //     if (empty($consult)) {
        //         $result = $estudiantes->update($codigo, $nombre, $apellido, $telefono, $direccion, $carrera, $nivel, $id_estudiante);
        //         if ($result) {
        //             $res = array('tipo' => 'success', 'mensaje' => 'ESTUDIANTE MODIFICADO');
        //         } else {
        //             $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL MODIFICAR');
        //         }
        //     } else {
        //         $res = array('tipo' => 'error', 'mensaje' => 'EL CODIGO YA EXISTE');
        //     }
        // }
        echo json_encode($res);
        break;
    case 'delete':
        $id = $_GET['id'];
        $data = $estudiantes->delete($id);
        if ($data) {
            $res = array('tipo' => 'success', 'mensaje' => 'ESTUDIANTE ELIMINADO');
        } else {
            $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL ELIMINAR');
        }
        echo json_encode($res);
        break;
    case 'edit':
        $id = $_GET['id'];
        $data = $estudiantes->getEstudiante($id);
        echo json_encode($data);
        break;
    case 'datos':
        $item = $_GET['item'];
        $data = $estudiantes->getDatos($item);
        echo json_encode($data);
        break;
    default:
        # code...
        break;
}
