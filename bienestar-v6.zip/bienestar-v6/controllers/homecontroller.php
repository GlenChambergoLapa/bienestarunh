<?php
class Home{
    
    public function index()
    {
        include 'views/index.php';
    }
}

?>