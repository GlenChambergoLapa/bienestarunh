<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once '../models/infopsicosocial.php';
$option = (empty($_GET['option'])) ? '' : $_GET['option'];
$infopsicosocial = new InfoPsicosocialModel();
$id_user = $_SESSION['idusuario'];

switch ($option) {
    case 'save':
        $economico_ap = $_POST['economico_ap'];
        $alimentacion_ap = $_POST['alimentacion_ap'];
        $vivienda_ap = $_POST['vivienda_ap'];
        $transporte_ap = $_POST['transporte_ap'];
        $familiar_ap = $_POST['familiar_ap'];
        $psicologico_ap = $_POST['psicologico_ap'];
        $consumealcohol_ap = $_POST['consumealcohol_ap'];
        $parentesco_ap = $_POST['parentesco_ap'];
        $existeviolencia_ap = $_POST['existeviolencia_ap'];
        $especifique_ap = $_POST['especifique_ap'];
        $id_alumno_ap = $_POST['id_alumno_ap'];

        $datoscheckboxpuniversidad_ap = '';
        $datoscheckboxpvives_ap = '';


        if(isset($_POST['puniversidad_ap'])){
            $datoscheckboxpuniversidad_ap = implode(', ', $_POST['puniversidad_ap']);
        }
        if(isset($_POST['pvives_ap'])){
            $datoscheckboxpvives_ap = implode(', ', $_POST['pvives_ap']);
        }




        $consul_idalumno = $infopsicosocial->getIdAlumno($id_user);
        $idalumno_ap = $consul_idalumno['idalumno'];

        // $res = array('tipo' => 'success', 'mensaje' => 'ID: '.$idalumno_aa);
        



        if ($id_alumno_ap == '') {

                $resultinfopsicosocial = $infopsicosocial->save($economico_ap, $alimentacion_ap, $vivienda_ap, $transporte_ap, $familiar_ap, $psicologico_ap, $consumealcohol_ap, $parentesco_ap, $existeviolencia_ap, $especifique_ap, $datoscheckboxpuniversidad_ap, $datoscheckboxpvives_ap, $idalumno_ap);
                
                if ($resultinfopsicosocial) {
                    $res = array('tipo' => 'success', 'mensaje' => 'INFO PSICOSOCIAL REGISTRADO');
                } else {
                    $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL AGREGAR INFO PSICOSOCIAL');
                }
                
            } 
            
    

        // else {
        //     $consult = $estudiantes->comprobarCodigo($codigo, $id_estudiante);
        //     if (empty($consult)) {
        //         $result = $estudiantes->update($codigo, $nombre, $apellido, $telefono, $direccion, $carrera, $nivel, $id_estudiante);
        //         if ($result) {
        //             $res = array('tipo' => 'success', 'mensaje' => 'ESTUDIANTE MODIFICADO');
        //         } else {
        //             $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL MODIFICAR');
        //         }
        //     } else {
        //         $res = array('tipo' => 'error', 'mensaje' => 'EL CODIGO YA EXISTE');
        //     }
        // }
        echo json_encode($res);
        break;
    case 'delete':
        $id = $_GET['id'];
        $data = $estudiantes->delete($id);
        if ($data) {
            $res = array('tipo' => 'success', 'mensaje' => 'ESTUDIANTE ELIMINADO');
        } else {
            $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL ELIMINAR');
        }
        echo json_encode($res);
        break;
    case 'edit':
        $id = $_GET['id'];
        $data = $estudiantes->getEstudiante($id);
        echo json_encode($data);
        break;
    case 'datos':
        $item = $_GET['item'];
        $data = $estudiantes->getDatos($item);
        echo json_encode($data);
        break;
    default:
        # code...
        break;
}
