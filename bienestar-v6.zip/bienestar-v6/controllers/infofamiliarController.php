<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once '../models/infofamiliar.php';

$option = (empty($_GET['option'])) ? '' : $_GET['option'];
$infofamiliar = new InfoFamiliarModel();
$id_user = $_SESSION['idusuario'];

switch ($option) {
    case 'save':
        $padres_af = $_POST['padres_af'];
        $orfandad_af = $_POST['orfandad_af'];
        $numhermanos_af = $_POST['numerodehermanos_af'];
        $otrosespecifique_af = $_POST['otrosespecifique_af'];
        
        $datoscheckbox_af = '';
        if(isset($_POST['viveactual_af'])){
            $datoscheckbox_af = implode(', ', $_POST['viveactual_af']);
        }
        
        $consul_idalumno = $infofamiliar->getIdAlumno($id_user);
        $idalumno_af = $consul_idalumno['idalumno'];
        
        $id_alumno_af = $_POST['id_alumno_af'];

        if ($id_alumno_af == '') {

            $consultinfofamiliar = $infofamiliar->save($padres_af, $orfandad_af, $numhermanos_af, $datoscheckbox_af, $otrosespecifique_af, $idalumno_af);
            
            if ($consultinfofamiliar) {
                
                $res = array('tipo' => 'success', 'mensaje' => 'INFO FAMILIAR REGISTRADO');
                
            } else {
                $res = array('tipo' => 'error', 'mensaje' => 'ERROR, INFO FAMILIAR NO REGISTRADO');
            }
        } 

        // else {
        //     $consult = $estudiantes->comprobarCodigo($codigo, $id_estudiante);
        //     if (empty($consult)) {
        //         $result = $estudiantes->update($codigo, $nombre, $apellido, $telefono, $direccion, $carrera, $nivel, $id_estudiante);
        //         if ($result) {
        //             $res = array('tipo' => 'success', 'mensaje' => 'ESTUDIANTE MODIFICADO');
        //         } else {
        //             $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL MODIFICAR');
        //         }
        //     } else {
        //         $res = array('tipo' => 'error', 'mensaje' => 'EL CODIGO YA EXISTE');
        //     }
        // }

        echo json_encode($res);
        break;

    case 'savefamilia':

        $apellidosnombres_af_m = $_POST['apepat_af_m'].' '.$_POST['apemat_af_m'].' '.$_POST['nombres_af_m'];
        $edad_af_m = $_POST['edad_af_m'];
        $sexo_af_m = $_POST['sexo_af_m'];
        $parentesco_af_m = $_POST['parentesco_af_m'];
        $numcel_af_m = $_POST['numcel_af_m'];
        $estadocivil_af_m = $_POST['estadocivil_af_m'];
        $gradoins_af_m = $_POST['gradoins_af_m'];
        $ocupacion_af_m = $_POST['ocupacion_af_m'];
        $ingrsemanal_af_m = $_POST['ingrsemanal_af_m'];
                
        $consul_idinfofamiliar = $infofamiliar->getIdInfoFamiliar($id_user);
        $idinfofamiliar_if = $consul_idinfofamiliar['idinfofamiliar'];
        
        if(empty($idinfofamiliar_if)){
            $res = array('tipo' => 'error', 'mensaje' => 'ERROR, NO TIENE REGISTRADO LOS ANTERIORES CAMPOS');
        }else{
            $consultagregarfamiliar = $infofamiliar->savefamiliar($apellidosnombres_af_m, $edad_af_m, $sexo_af_m, $parentesco_af_m, $numcel_af_m, $estadocivil_af_m, $gradoins_af_m, $ocupacion_af_m, $ingrsemanal_af_m, $idinfofamiliar_if);
                
            if ($consultagregarfamiliar) {
                $res = array('tipo' => 'success', 'mensaje' => 'FAMILIAR REGISTRADO');
            } else {
                $res = array('tipo' => 'error', 'mensaje' => 'ERROR, FAMILIAR NO REGISTRADO');
            }
        }
            
        echo json_encode($res);
        break;
    
    case 'listarfamiliar':

        $data = $infofamiliar->getDatosFamiliarAF($id_user);
        for ($i = 0; $i < count($data); $i++) {
            $data[$i]['ApellidosNombres'] = $data[$i]['ApellidosNombres'];
            $data[$i]['Edad'] = $data[$i]['Edad'];
            $data[$i]['Sexo'] = $data[$i]['Sexo'];
            $data[$i]['Parentesco'] = $data[$i]['Parentesco'];
            $data[$i]['Celular'] = $data[$i]['Celular'];
            $data[$i]['EstadoCivil'] = $data[$i]['EstadoCivil'];
            $data[$i]['GradoInstruccion'] = $data[$i]['GradoInstruccion'];
            $data[$i]['Ocupacion'] = $data[$i]['Ocupacion'];
            $data[$i]['IngresoSemanal'] = $data[$i]['IngresoSemanal'];
            
        }
        echo json_encode($data);
        break;

    // case 'delete':
    //     $id = $_GET['id'];
    //     $data = $estudiantes->delete($id);
    //     if ($data) {
    //         $res = array('tipo' => 'success', 'mensaje' => 'ESTUDIANTE ELIMINADO');
    //     } else {
    //         $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL ELIMINAR');
    //     }
    //     echo json_encode($res);
    //     break;
    // case 'edit':
    //     $id = $_GET['id'];
    //     $data = $estudiantes->getEstudiante($id);
    //     echo json_encode($data);
    //     break;
    // case 'datos':
    //     $item = $_GET['item'];
    //     $data = $estudiantes->getDatos($item);
    //     echo json_encode($data);
    //     break;
    default:
        # code...
        break;
}

