<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once '../models/fichasocioeconomica.php';
$option = (empty($_GET['option'])) ? '' : $_GET['option'];
$fichasocioeconomica = new FichaSocioeconomicaModel();
$id_user = $_SESSION['idusuario'];

switch ($option) {
    case 'listar':
        $data = $fichasocioeconomica->getFichasSocioeconomicas();
        for ($i = 0; $i < count($data); $i++) {

            $data[$i]['Nombre'] = $data[$i]['Nombre'].' '.$data[$i]['ApellidoPaterno'].' '.$data[$i]['ApellidoMaterno'];
            $data[$i]['DNI'] = $data[$i]['DNI'];
            $data[$i]['result'] = $fichasocioeconomica->evaluarFicha($data[$i]['IdAlumno']);
            
            // $data[$i]['accion'] = '<div class="d-flex">
            // <a class="btn btn-danger btn-sm" onclick="generarPDFFS(' . $data[$i]['IdAlumno'] . ')"><i class="fas fa-file-pdf"></i></a>
            // </div>';
            // Crear array con datos fichasocioeconomica
            
            # $datafichasocioeconomica = array(
            #    'nombresapellidos' => $fichasocioeconomica->getNombresApellidos($data[$i]['IdAlumno']),
            #    'fechanacimiento' => $fichasocioeconomica->getFechaNacimiento($data[$i]['IdAlumno'])
            # )

            $data[$i]['accion'] = '<div class="d-flex">
            <a href="views/fichasocioeconomicapdf.php?idal='.$data[$i]['IdAlumno'].'" target="_black" class="btn btn-danger btn-sm"><i class="fas fa-file-pdf"></i></a>
            </div>';
            # $data[$i]['accion'] = '<div class="d-flex">
            # <a href="views/fichasocioeconomica/fichasocioeconomicapdf.php?idal='.$datafichasocioeconomica.'" target="_black" class="btn btn-danger btn-sm"><i class="fas fa-file-pdf"></i></a>
            # </div>';
        }
        echo json_encode($data);
        break;
        
    case 'listaralumno':
        $data = $fichasocioeconomica->getFichasSocioeconomicaAlumno($id_user);
        for ($i = 0; $i < count($data); $i++) {
            $data[$i]['Nombre'] = $data[$i]['Nombre'].' '.$data[$i]['ApellidoPaterno'].' '.$data[$i]['ApellidoMaterno'];
            $data[$i]['DNI'] = $data[$i]['DNI'];
            // $data[$i]['accion'] = '<div class="d-flex">
            // <a class="btn btn-danger btn-sm" onclick="generarPDFFS(' . $data[$i]['IdAlumno'] . ')"><i class="fas fa-file-pdf"></i></a>
            // </div>';
            // Crear array con datos fichasocioeconomica
            
            # $datafichasocioeconomica = array(
            #    'nombresapellidos' => $fichasocioeconomica->getNombresApellidos($data[$i]['IdAlumno']),
            #    'fechanacimiento' => $fichasocioeconomica->getFechaNacimiento($data[$i]['IdAlumno'])
            # )

            $data[$i]['accion'] = '<div class="d-flex">
            <a href="views/fichasocioeconomicapdf.php?idal='.$data[$i]['IdAlumno'].'" target="_black" class="btn btn-danger btn-sm"><i class="fas fa-file-pdf"></i></a>
            </div>';
            # $data[$i]['accion'] = '<div class="d-flex">
            # <a href="views/fichasocioeconomica/fichasocioeconomicapdf.php?idal='.$datafichasocioeconomica.'" target="_black" class="btn btn-danger btn-sm"><i class="fas fa-file-pdf"></i></a>
            # </div>';
        }
        echo json_encode($data);
        break;
    case 'reportepdf':
        $idalumno = $_GET['id'];

        header ("Location: ../views/fichasocioeconomicapdf.php?idal=".$idalumno);

        break;
    // case 'verAsistencia':
    //         $estudiante = $_GET['estudiante'];
    //         $data = $asistencias->getFiltroAsistencia($estudiante);
    //         for ($i = 0; $i < count($data); $i++) {
    //             $data[$i]['start'] = $data[$i]['fecha'];
    //             $data[$i]['color'] = '#00d082';
    //             //$data[$i]['end'] = $data[$i]['salida'];
    //             $data[$i]['title'] = $data[$i]['estudiante'];
    //         }
    //         echo json_encode($data);
    //         break;
    case 'registrar':
        $codigo = $_POST['codigo'];
        $accion = $_POST['radio'];
        $consult = $asistencias->getEstudiante($codigo);
        if (empty($consult)) {
            $res = array('tipo' => 'error', 'mensaje' => 'EL CODIGO NO EXISTE');
        } else {
            $fecha = date('Y-m-d');
            if ($accion == 'entrada') {
                $entrada = date('Y-m-d H:i:s');
                $verificarEntrada = $asistencias->getAsistencia($fecha, $consult['id']);
                if (empty($verificarEntrada)) {
                    $registrar = $asistencias->registrarEntrada($entrada, $fecha, $consult['id']);
                    if ($registrar) {
                        $res = array('tipo' => 'success', 'mensaje' => 'INGRESO REGISTRADO');
                    } else {
                        $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL REGISTRAR');
                    }
                } else {
                    $res = array('tipo' => 'error', 'mensaje' => 'ENTRADA YA ESTA REGISTRADA');
                }
            } else {
                $salida = date('Y-m-d H:i:s');
                $verificarEntrada = $asistencias->getAsistencia($fecha, $consult['id']);
                if (!empty($verificarEntrada)) {
                    $registrar = $asistencias->registrarSalida($salida, $verificarEntrada['id']);
                    if ($registrar) {
                        $res = array('tipo' => 'success', 'mensaje' => 'SALIDA REGISTRADO');
                    } else {
                        $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL REGISTRAR');
                    }
                } else {
                    $res = array('tipo' => 'error', 'mensaje' => 'NO SE REGISTRO EL INGRESO DEL ESTUDIANTE');
                }
            }
        }
        echo json_encode($res);
        break;
    case 'buscarEstudiante':
        $array = array();
        $valor = $_GET['term'];
        $data = $asistencias->buscarEstudiante($valor);
        foreach ($data as $row) {
            $result['id'] = $row['id'];
            $result['label'] = $row['nombre'];
            $result['carrera'] = $row['id_carrera'];
            $result['nivel'] = $row['id_nivel'];
            array_push($array, $result);
        }
        echo json_encode($array);
        break;
    default:
        # code...
        break;
}

// // FUNCION PARA SABER LAS EVALUACIONES DE FICHA SOCIOECONOMICA
// function public evaluarTablaCalificacionSocioeconomica($idalumno)
// {
//     // $resultadofinal = '';
//     // $resultadoescala = '';
    
//     // // ID PROVINCIA HUANCAVELICA 84
//     // // ID DEPARTAMENTO HUANCAVELICA 8

//     // // PUNTAJES DE LAS VARIABLES
//     // $procedenciaestudiante=0;

//     // // PROCEDENCIA DEL ESTUDIANTE
//     // foreach ($fichasocioeconomica->getDatosProcedenciaAlumno($idalumno) as $row) {
//     //     $iddepartamentoda_dg = $row['iddepartamento'];
//     //     $idprovinciada_dg = $row['idprovincia'];
//     //     $iddistritoda_dg = $row['iddistrito'];
//     // }

//     // if($idprovinciada_dg == 84){
//     //     $procedenciaestudiante = 1;
//     // }elseif($iddepartamentoda_dg == 4){
//     //     $procedenciaestudiante = 2;
//     // }elseif($iddepartamentoda_dg != 4){
//     //     $procedenciaestudiante = 3;
//     // }

//     // if($procedenciaestudiante > 2){
//     //     $resultadoescala = 'ESCALA A';
//     // }else {
//     //     $resultadoescala = 'ESCALA B';
//     // }

//     $resultadofinal = 'hola';
    

//     return $resultadofinal;
// }



