<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once '../models/infoeconomica.php';
$option = (empty($_GET['option'])) ? '' : $_GET['option'];
$infoeconomica = new InfoEconomicaModel();
$id_user = $_SESSION['idusuario'];

switch ($option) {
    case 'save':
        $dependencia_ie = $_POST['dependencia_ie'];
        $otrosespecifique_ie = $_POST['otrosespecifique_ie'];
        $ingresofamsemanal_ie = $_POST['ingresofamsemanal_ie'];
        $actividadeconomica_ie = $_POST['actividadeconomica_ie'];
        $especifique_ie = $_POST['especifique_ie'];
        $ingresosemanal_ie = $_POST['ingresosemanal_ie'];
        
        $id_alumno_ie = $_POST['id_alumno_ie'];

        $consul_idalumno = $infoeconomica->getIdAlumno($id_user);
        $idalumno_ie = $consul_idalumno['idalumno'];

        // $res = array('tipo' => 'success', 'mensaje' => 'ID: '.$idalumno_aa);

        if ($id_alumno_ie == '') {
            
                $resultinfoeconomica = $infoeconomica->save($dependencia_ie, $otrosespecifique_ie, $ingresofamsemanal_ie, $actividadeconomica_ie, $especifique_ie, $ingresosemanal_ie, $idalumno_ie);
                
                if ($resultinfoeconomica) {
                    $res = array('tipo' => 'success', 'mensaje' => 'INFO ECONOMICA REGISTRADO');
                } else {
                    $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL AGREGAR INFO ECONOMICA');
                }
        } 

        // else {
        //     $consult = $estudiantes->comprobarCodigo($codigo, $id_estudiante);
        //     if (empty($consult)) {
        //         $result = $estudiantes->update($codigo, $nombre, $apellido, $telefono, $direccion, $carrera, $nivel, $id_estudiante);
        //         if ($result) {
        //             $res = array('tipo' => 'success', 'mensaje' => 'ESTUDIANTE MODIFICADO');
        //         } else {
        //             $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL MODIFICAR');
        //         }
        //     } else {
        //         $res = array('tipo' => 'error', 'mensaje' => 'EL CODIGO YA EXISTE');
        //     }
        // }
        echo json_encode($res);
        break;
    case 'delete':
        $id = $_GET['id'];
        $data = $estudiantes->delete($id);
        if ($data) {
            $res = array('tipo' => 'success', 'mensaje' => 'ESTUDIANTE ELIMINADO');
        } else {
            $res = array('tipo' => 'error', 'mensaje' => 'ERROR AL ELIMINAR');
        }
        echo json_encode($res);
        break;
    case 'edit':
        $id = $_GET['id'];
        $data = $estudiantes->getEstudiante($id);
        echo json_encode($data);
        break;
    case 'datos':
        $item = $_GET['item'];
        $data = $estudiantes->getDatos($item);
        echo json_encode($data);
        break;
    default:
        # code...
        break;
}
