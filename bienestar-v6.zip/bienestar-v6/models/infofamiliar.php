<?php
require_once '../config.php';
require_once 'conexion.php';

class InfoFamiliarModel{
    private $pdo, $con;
    public function __construct() {
        $this->con = new Conexion();
        $this->pdo = $this->con->conectar();
    }

    public function getIdAlumno($iduser)
    {
        $consult = $this->pdo->prepare("SELECT info_alumno.IdAlumno as idalumno FROM usuario INNER JOIN info_alumno ON usuario.IdUsuario=info_alumno.IdUsuario WHERE usuario.IdUsuario= ?");
        $consult->execute([$iduser]);
        return $consult->fetch(PDO::FETCH_ASSOC);
    }

    public function save($padres_af, $orfandad_af, $numhermanos_af, $datoscheckbox_af, $otros, $idalumno_af)
    {
        $consult = $this->pdo->prepare("INSERT INTO info_familiar (EstadoCPadres, Orfandad, Hermanos, Vivecon, Otros, IdAlumno) VALUES (?,?,?,?,?,?)");
        return $consult->execute([$padres_af, $orfandad_af, $numhermanos_af, $datoscheckbox_af, $otros, $idalumno_af]);
    } 
    
    public function getIdInfoFamiliar($iduser)
    {
        $consult = $this->pdo->prepare("SELECT info_familiar.IdInfoFamilia as idinfofamiliar FROM usuario INNER JOIN info_alumno ON usuario.IdUsuario=info_alumno.IdUsuario INNER JOIN info_familiar ON info_alumno.IdAlumno=info_familiar.IdAlumno WHERE usuario.IdUsuario=?");
        $consult->execute([$iduser]);
        return $consult->fetch(PDO::FETCH_ASSOC);
    }

    public function savefamiliar($apellidosnombres_af_m, $edad_af_m, $sexo_af_m, $parentesco_af_m, $numcel_af_m, $estadocivil_af_m, $gradoins_af_m, $ocupacion_af_m, $ingrsemanal_af_m, $consultidinfofamiliar)
    {
        $consult = $this->pdo->prepare("INSERT INTO estructura_familiar (ApellidosNombres, Edad, Sexo, Parentesco, Celular, EstadoCivil, GradoInstruccion, Ocupacion, IngresoSemanal, IdInfoFamilia) VALUES (?,?,?,?,?,?,?,?,?,?)");
        return $consult->execute([$apellidosnombres_af_m, $edad_af_m, $sexo_af_m, $parentesco_af_m, $numcel_af_m, $estadocivil_af_m, $gradoins_af_m, $ocupacion_af_m, $ingrsemanal_af_m, $consultidinfofamiliar]);
    }

    public function getDatosFamiliarAF($iduser)
    {
        $consult = $this->pdo->prepare("SELECT * FROM estructura_familiar INNER JOIN info_familiar ON estructura_familiar.IdInfoFamilia=info_familiar.IdInfoFamilia INNER JOIN info_alumno ON info_familiar.IdAlumno=info_alumno.IdAlumno WHERE info_alumno.IdUsuario=?");
        $consult->execute([$iduser]);
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }


}
