<?php
require_once '../config.php';
require_once 'conexion.php';
class InfoEconomicaModel{
    private $pdo, $con;
    public function __construct() {
        $this->con = new Conexion();
        $this->pdo = $this->con->conectar();
    }
    
    public function getIdAlumno($iduser)
    {
        $consult = $this->pdo->prepare("SELECT info_alumno.IdAlumno as idalumno FROM usuario INNER JOIN info_alumno ON usuario.IdUsuario=info_alumno.IdUsuario WHERE usuario.IdUsuario= ?");
        $consult->execute([$iduser]);
        return $consult->fetch(PDO::FETCH_ASSOC);
    }

    public function save($dependencia_ie, $otrosespecifique_ie, $ingresofamsemanal_ie, $actividadeconomica_ie, $especifique_ie, $ingresosemanal_ie, $idalumno_ie)
    {
        $consult = $this->pdo->prepare("INSERT INTO info_economica (Dependencia, Otrosde, IngresoFamSemanal, ActividadEconomica, Especificar_ie,IngresoSemanal, IdAlumno) VALUES (?,?,?,?,?,?,?)");
        return $consult->execute([$dependencia_ie, $otrosespecifique_ie, $ingresofamsemanal_ie, $actividadeconomica_ie, $especifique_ie, $ingresosemanal_ie, $idalumno_ie]);
    }  


}