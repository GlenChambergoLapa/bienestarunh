<?php
require_once '../config.php';
require_once 'conexion.php';
class InfoAlimentacionModel{
    private $pdo, $con;
    public function __construct() {
        $this->con = new Conexion();
        $this->pdo = $this->con->conectar();
    }
    
    public function getIdAlumno($iduser)
    {
        $consult = $this->pdo->prepare("SELECT info_alumno.IdAlumno as idalumno FROM usuario INNER JOIN info_alumno ON usuario.IdUsuario=info_alumno.IdUsuario WHERE usuario.IdUsuario= ?");
        $consult->execute([$iduser]);
        return $consult->fetch(PDO::FETCH_ASSOC);
    }

    public function save($cocinacasa_ia, $detalle_ia, $tipococina_ia, $comedoruniv_ia, $idalumno_ia)
    {
        $consult = $this->pdo->prepare("INSERT INTO info_alimentacion (CocinaGas, Detalle, TipoCocina, ComedorUniv, IdAlumno) VALUES (?,?,?,?,?)");
        return $consult->execute([$cocinacasa_ia, $detalle_ia, $tipococina_ia, $comedoruniv_ia, $idalumno_ia]);
    }  


}