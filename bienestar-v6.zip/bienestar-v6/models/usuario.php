<?php
require_once '../config.php';
require_once 'conexion.php';
class UsuarioModel{
    private $pdo, $con;
    public function __construct() {
        $this->con = new Conexion();
        $this->pdo = $this->con->conectar();
    }

    public function getUsers()
    {
        $consult = $this->pdo->prepare("SELECT * FROM usuario");
        $consult->execute();
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getUser($id)
    {
        $consult = $this->pdo->prepare("SELECT * FROM usuario WHERE IdUsuario = ?");
        $consult->execute([$id]);
        return $consult->fetch(PDO::FETCH_ASSOC);
    }

    public function comprobarUsuario($usuario)
    {
        $consult = $this->pdo->prepare("SELECT * FROM usuario WHERE usuario = ?");
        $consult->execute([$usuario]);
        return $consult->fetch(PDO::FETCH_ASSOC);
    }

    public function saveUser($usuario, $contrasena, $perfil, $estado)
    {
        $consult = $this->pdo->prepare("INSERT INTO usuario (usuario, contraseña, perfil, estado) VALUES (?,?,?,?)");
        return $consult->execute([$usuario, $contrasena, $perfil, $estado]);
    }
  # Falta codificar     
    public function deleteUser($id)
    {
        $consult = $this->pdo->prepare("DELETE FROM usuario WHERE IdUsuario = ?");
        return $consult->execute([$id]);
    }

    public function updateUser($usuario, $perfil, $estado, $id)
    {
        $consult = $this->pdo->prepare("UPDATE usuario SET usuario=?, perfil=?, estado=? WHERE IdUsuario=?");
        return $consult->execute([$usuario, $perfil, $estado, $id]);
    }
}

?>