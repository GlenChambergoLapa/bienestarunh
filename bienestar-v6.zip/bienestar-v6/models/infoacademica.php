<?php
require_once '../config.php';
require_once 'conexion.php';
class InfoAcademicaModel{
    private $pdo, $con;
    public function __construct() {
        $this->con = new Conexion();
        $this->pdo = $this->con->conectar();
    }
    
    public function getIdAlumno($iduser)
    {
        $consult = $this->pdo->prepare("SELECT info_alumno.IdAlumno as idalumno FROM usuario INNER JOIN info_alumno ON usuario.IdUsuario=info_alumno.IdUsuario WHERE usuario.IdUsuario= ?");
        $consult->execute([$iduser]);
        return $consult->fetch(PDO::FETCH_ASSOC);
    }

    public function comprobarCodigoMatricula($codigomatricula_aa, $accion)
    {
        if ($accion == 0) {
            $consult = $this->pdo->prepare("SELECT * FROM info_academica WHERE CodigoMatricula = ?");
            $consult->execute([$codigomatricula_aa]);
        } else {
            $consult = $this->pdo->prepare("SELECT * FROM info_academica WHERE CodigoMatricula = ? AND IdAlumno != ?");
            $consult->execute([$codigomatricula_aa, $accion]);
        }
        return $consult->fetch(PDO::FETCH_ASSOC);
    }

    public function save($codigomatricula_aa, $ciclo_aa, $segundacarrera_aa, $promedioponderado_aa, $numcursosdesaprobados_aa, $numcursoacargo_aa, $modalidadingreso_aa, $abandonoestudios_aa, $motivo_aa, $idalumno_aa, $carrera_aa)
    {
        $consult = $this->pdo->prepare("INSERT INTO info_academica (CodigoMatricula, Ciclo, SegundaCarrera, PromedioAnterior, CursosDesaprobados, CursosCargo, ModalidadIngreso, Abandono, Motivo, IdAlumno, IdCarrera) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
        return $consult->execute([$codigomatricula_aa, $ciclo_aa, $segundacarrera_aa, $promedioponderado_aa, $numcursosdesaprobados_aa, $numcursoacargo_aa, $modalidadingreso_aa, $abandonoestudios_aa, $motivo_aa, $idalumno_aa, $carrera_aa]);
    }  


}
