<?php
require_once '../config.php';
require_once 'conexion.php';
class DatosGeneralesModel{
    private $pdo, $con;
    public function __construct() {
        $this->con = new Conexion();
        $this->pdo = $this->con->conectar();
    }

    public function getEstudiantes()
    {
        $consult = $this->pdo->prepare("SELECT e.*, c.nombre AS carrera, n.nombre AS nivel FROM estudiantes e INNER JOIN carreras c ON e.id_carrera = c.id INNER JOIN niveles n ON e.id_nivel = n.id WHERE e.estado = 1");
        $consult->execute();
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }

    // public function getDatos($table)
    // {
    //     $consult = $this->pdo->prepare("SELECT * FROM $table WHERE estado = ?");
    //     $consult->execute([1]);
    //     return $consult->fetchAll(PDO::FETCH_ASSOC);
    // }

    public function getIdDomicilio($domicilioactual_dg)
    {
        $consult = $this->pdo->prepare("SELECT * FROM domicilio WHERE Direccion = ?");
        $consult->execute([$domicilioactual_dg]);
        return $consult->fetch(PDO::FETCH_ASSOC);
    }
    
    public function getIdNacimiento($lugarnacimiento_dg)
    {
        $consult = $this->pdo->prepare("SELECT * FROM lugar_nacimiento WHERE Lugar = ?");
        $consult->execute([$lugarnacimiento_dg]);
        return $consult->fetch(PDO::FETCH_ASSOC);
    }

    public function comprobarDniAlumno($dni_dg, $accion)
    {
        if ($accion == 0) {
            $consult = $this->pdo->prepare("SELECT * FROM info_alumno WHERE DNI = ?");
            $consult->execute([$dni_dg]);
        } else {
            $consult = $this->pdo->prepare("SELECT * FROM info_alumno WHERE DNI = ? AND IdAlumno != ?");
            $consult->execute([$dni_dg, $accion]);
        }
        return $consult->fetch(PDO::FETCH_ASSOC);
    }

    public function saveDomicilio($domicilioactual_dg, $referenciadomicilio_dg, $anexoda_dg, $distritoda_dg)
    {
        $consult = $this->pdo->prepare("INSERT INTO domicilio (Direccion, Referencia, Anexo, IdDistrito) VALUES (?,?,?,?)");
        return $consult->execute([$domicilioactual_dg, $referenciadomicilio_dg, $anexoda_dg, $distritoda_dg]);
    }

    public function saveLugarNacimiento($lugarnacimiento_dg, $anexoln_dg, $distritoln_dg)
    {
        $consult = $this->pdo->prepare("INSERT INTO lugar_nacimiento (Lugar, Anexo_ln, IdDistrito) VALUES (?,?,?)");
        return $consult->execute([$lugarnacimiento_dg, $anexoln_dg, $distritoln_dg]);
    }

    // Guardar Info Alumno
    public function save($nombres, $apepat, $apemat, $fecnacimiento, $edad, $genero, $dni, $telcel, $correo, $estcivil, $numhijos, $iddomicilio, $idnacimiento, $iduser)
    {
        $consult = $this->pdo->prepare("INSERT INTO info_alumno (Nombre, ApellidoPaterno, ApellidoMaterno, FechaNacimiento, Edad, Genero, DNI, Telefono, Correo, EstadoCivil, NumeroHijos, IdDomicilio, IdNacimiento, IdUsuario) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        return $consult->execute([$nombres, $apepat, $apemat, $fecnacimiento, $edad, $genero, $dni, $telcel, $correo, $estcivil, $numhijos, $iddomicilio, $idnacimiento, $iduser]);
    }

    public function delete($id)
    {
        $consult = $this->pdo->prepare("UPDATE estudiantes SET estado = ? WHERE id = ?");
        return $consult->execute([0, $id]);
    }

    public function update($codigo, $nombre, $apellido, $telefono, $direccion, $carrera,$nivel, $id)
    {
        $consult = $this->pdo->prepare("UPDATE estudiantes SET codigo=?, nombre=?, apellido=?, telefono=?, direccion=?, id_carrera=?, id_nivel=? WHERE id=?");
        return $consult->execute([$codigo, $nombre, $apellido, $telefono, $direccion, $carrera,$nivel, $id]);
    }
}
