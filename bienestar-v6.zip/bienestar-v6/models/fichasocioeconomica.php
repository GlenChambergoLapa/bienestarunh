<?php
require_once '../config.php';
require_once 'conexion.php';

class FichaSocioeconomicaModel{

    private $pdo, $con;
    public function __construct() {
        $this->con = new Conexion();
        $this->pdo = $this->con->conectar();
    }

    public function getFichasSocioeconomicas()
    {
        $consult = $this->pdo->prepare("SELECT * FROM info_alumno");
        $consult->execute();
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getNombresApellidos($idalumno)
    {
        $consult = $this->pdo->prepare("SELECT CONCAT(Nombre, ' ', ApellidoPaterno, ' ', ApellidoMaterno) AS alumno FROM info_alumno WHERE IdAlumno = ?");
        $consult->execute([$idalumno]);
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getFichasSocioeconomicaAlumno($iduser)
    {
        $consult = $this->pdo->prepare("SELECT * FROM info_alumno WHERE IdUsuario = ?");
        $consult->execute([$iduser]);
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }

    // REPORTE FICHA SOCIOECONOMICA PDF
    public function getDatosInfoAlumno($idalumno)
    {
        $consult = $this->pdo->prepare("SELECT * FROM info_alumno INNER JOIN domicilio ON info_alumno.IdDomicilio=domicilio.IdDomicilio INNER JOIN lugar_nacimiento ON info_alumno.IdNacimiento=lugar_nacimiento.IdNacimiento WHERE info_alumno.IdAlumno = ?");
        $consult->execute([$idalumno]);
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getDatosDomicilioAlumno($idalumno)
    {
        $consult = $this->pdo->prepare("SELECT departamento.Nombre as nomdepartamento, provincia.Nombre as nomprovincia, distrito.Nombre as nomdistrito FROM departamento INNER JOIN provincia ON departamento.IdDepartamento=provincia.IdDepartamento INNER JOIN distrito ON provincia.IdProvincia=distrito.IdProvincia INNER JOIN domicilio ON distrito.IdDistrito=domicilio.IdDistrito INNER JOIN info_alumno ON domicilio.IdDomicilio=info_alumno.IdDomicilio WHERE info_alumno.IdAlumno = ?");
        $consult->execute([$idalumno]);
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getDatosNacimientoAlumno($idalumno)
    {
        $consult = $this->pdo->prepare("SELECT departamento.Nombre as nomdepartamento, provincia.Nombre as nomprovincia, distrito.Nombre as nomdistrito FROM departamento INNER JOIN provincia ON departamento.IdDepartamento=provincia.IdDepartamento INNER JOIN distrito ON provincia.IdProvincia=distrito.IdProvincia INNER JOIN lugar_nacimiento ON distrito.IdDistrito=lugar_nacimiento.IdDistrito INNER JOIN info_alumno ON lugar_nacimiento.IdNacimiento=info_alumno.IdNacimiento WHERE info_alumno.IdAlumno = ?");
        $consult->execute([$idalumno]);
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }

    // ASPECTO ACADEMICO

    public function getAspectoAcademico($idalumno)
    {
        $consult = $this->pdo->prepare("SELECT * FROM info_academica INNER JOIN carrera ON info_academica.IdCarrera=carrera.IdCarrera WHERE info_academica.IdAlumno=?");
        $consult->execute([$idalumno]);
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }

    // ASPECTO FAMILIA

    public function getAspectoFamilia($idalumno)
    {
        $consult = $this->pdo->prepare("SELECT * FROM info_familiar INNER JOIN info_alumno ON info_familiar.IdAlumno=info_alumno.IdAlumno WHERE info_alumno.IdAlumno=?");
        $consult->execute([$idalumno]);
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // ESTRUCTURA FAMILIAR
    public function getEstructuraFamAspectoFamilia($idalumno)
    {
        $consult = $this->pdo->prepare("SELECT * FROM estructura_familiar WHERE IdInfoFamilia=(SELECT info_familiar.IdInfoFamilia FROM info_familiar INNER JOIN info_alumno ON info_familiar.IdAlumno=info_alumno.IdAlumno WHERE info_alumno.IdAlumno=?)");
        $consult->execute([$idalumno]);
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }

    // ASPECTO ECONOMICA
    public function getAspectoEconomica($idalumno)
    {
        $consult = $this->pdo->prepare("SELECT * FROM info_economica INNER JOIN info_alumno ON info_economica.IdAlumno=info_alumno.IdAlumno WHERE info_alumno.IdAlumno=?");
        $consult->execute([$idalumno]);
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }

    // ASPECTO VIVIENDA
    public function getAspectoVivienda($idalumno)
    {
        $consult = $this->pdo->prepare("SELECT * FROM info_vivienda INNER JOIN info_alumno ON info_vivienda.IdAlumno=info_alumno.IdAlumno WHERE info_alumno.IdAlumno=?");
        $consult->execute([$idalumno]);
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }

    // ASPECTO ALIMENTACION
    public function getAspectoAlimentacion($idalumno)
    {
        $consult = $this->pdo->prepare("SELECT * FROM info_alimentacion INNER JOIN info_alumno ON info_alimentacion.IdAlumno=info_alumno.IdAlumno WHERE info_alumno.IdAlumno=?");
        $consult->execute([$idalumno]);
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }

    // ASPECTO SALUD
    public function getAspectoSalud($idalumno)
    {
        $consult = $this->pdo->prepare("SELECT * FROM info_salud INNER JOIN info_alumno ON info_salud.IdAlumno=info_alumno.IdAlumno WHERE info_alumno.IdAlumno=?");
        $consult->execute([$idalumno]);
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }

    // ASPECTO PSICOSOCIAL
    public function getAspectoPsicosocial($idalumno)
    {
        $consult = $this->pdo->prepare("SELECT * FROM info_psicosocial INNER JOIN info_alumno ON info_psicosocial.IdAlumno=info_alumno.IdAlumno WHERE info_alumno.IdAlumno=?");
        $consult->execute([$idalumno]);
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }
    // public function getFiltro($carrera, $nivel)
    // {
    //     $consult = $this->pdo->prepare("SELECT a.*, CONCAT(e.nombre, ' ', e.apellido) AS estudiante FROM asistencias a INNER JOIN estudiantes e ON a.id_estudiante = e.id INNER JOIN carreras c ON e.id_carrera = c.id INNER JOIN niveles n ON e.id_nivel = n.id WHERE c.id = ? AND n.id = ?");
    //     $consult->execute([$carrera, $nivel]);
    //     return $consult->fetchAll(PDO::FETCH_ASSOC);
    // }

    // public function getFiltroAsistencia($id_estudiante)
    // {
    //     $consult = $this->pdo->prepare("SELECT a.*, CONCAT(e.nombre, ' ', e.apellido) AS estudiante FROM asistencias a INNER JOIN estudiantes e ON a.id_estudiante = e.id WHERE a.id_estudiante = ?");
    //     $consult->execute([$id_estudiante]);
    //     return $consult->fetchAll(PDO::FETCH_ASSOC);
    // }

    


    // EVALUACION DE LA TABLA CALIFICACION SOCIOECONOMICA
    public function getDatosProcedenciaAlumno($idalumno)
    {
        $consult = $this->pdo->prepare("SELECT departamento.IdDepartamento as iddepartamento, provincia.IdProvincia as idprovincia, distrito.IdDistrito as iddistrito FROM departamento INNER JOIN provincia ON departamento.IdDepartamento=provincia.IdDepartamento INNER JOIN distrito ON provincia.IdProvincia=distrito.IdProvincia INNER JOIN domicilio ON distrito.IdDistrito=domicilio.IdDistrito INNER JOIN info_alumno ON domicilio.IdDomicilio=info_alumno.IdDomicilio WHERE info_alumno.IdAlumno = ?");
        $consult->execute([$idalumno]);
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }

    public function evaluarFicha($idalumno)
    {
        $sumaresultados = 0;
        $resultadoescala = '';
        
        // ID PROVINCIA HUANCAVELICA 84
        // ID DEPARTAMENTO HUANCAVELICA 8

        // PUNTAJES DE LAS VARIABLES
        $procedenciaestudiante = 0;
        $dependenciaeconomica = 0;
        $condicionlaboral = 0;
        $discapacidad = 0;
        $orfandad = 0;

        // PROCEDENCIA DEL ESTUDIANTE
        foreach (self::getDatosProcedenciaAlumno($idalumno) as $row) {
            $iddepartamentoda_dg = $row['iddepartamento'];
            $idprovinciada_dg = $row['idprovincia'];
            $iddistritoda_dg = $row['iddistrito'];
        }
        if($idprovinciada_dg == 84){
            $procedenciaestudiante = 1;
        }elseif($iddepartamentoda_dg == 4){
            $procedenciaestudiante = 2;
        }elseif($iddepartamentoda_dg != 4){
            $procedenciaestudiante = 3;
        }

        // DEPENDENCIA ECONOMICA
        // foreach (self::getAspectoEconomica($idalumno) as $row) {
            // $dependencia_e = $row['Dependencia'];
            // $condicionlaboral_e = $row['Especificar_ie'];
        // }

        // if($dependencia_e == 'AMBOS PADRES'){
        //     $dependenciaeconomica = 1;
        // }elseif($dependencia_e == 'SOLO PAPA' || $dependencia_e == 'SOLO MAMA'){
        //     $dependenciaeconomica = 2;
        // }elseif($dependencia_e == 'DE SI MISMO'){
        //     $dependenciaeconomica = 3;
        // }else {
        //     $dependenciaeconomica = 4;
        // }
        
        // CONDICION LABORAL
        // if($condicionlaboral_e == 'CONTRATADO'){
        //     $condicionlaboral = 1;
        // }elseif($condicionlaboral_e == 'INDEPENDIENTE'){
        //     $condicionlaboral = 2;
        // }elseif($condicionlaboral_e == 'EVENTUAL'){
        //     $condicionlaboral = 3;
        // }elseif($condicionlaboral_e == 'DESEMPLEADO') {
        //     $condicionlaboral = 4;
        // }

        // DISCAPACIDAD
        

        // ORFANDAD
        // foreach (self::getAspectoFamilia($idalumno) as $row) {
        //     $orfandad_af = $row['Orfandad'];
        // }
        // if($orfandad_af == 'N.A.'){
        //     $orfandad = 1;
        // }elseif($orfandad_af == 'Parcial'){
        //     $orfandad = 2;
        // }elseif($orfandad_af == 'Total'){
        //     $orfandad = 3;
        // }
        

        // Sumar todos los resultados
        $sumaresultados = $procedenciaestudiante + $dependenciaeconomica + $condicionlaboral + $discapacidad + $orfandad;

        if($sumaresultados >= 0 && $sumaresultados <= 10){
            $resultadoescala = 'ESCALA A - DE ( 0 A 10)';
        }elseif($sumaresultados >= 11 && $sumaresultados <= 20) {
            $resultadoescala = 'ESCALA B - DE ( 11 A 20 )';
        }elseif($sumaresultados >= 21 && $sumaresultados <= 30) {
            $resultadoescala = 'ESCALA C - DE ( 21 A 30)';
        }

        return $resultadoescala;
    }
    
}   
