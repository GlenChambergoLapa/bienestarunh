<?php
require_once '../config.php';
require_once 'conexion.php';
class CarreraModel{
    private $pdo, $con;
    public function __construct() {
        $this->con = new Conexion();
        $this->pdo = $this->con->conectar();
    }

    public function getCarreras()
    {
        $consult = $this->pdo->prepare("SELECT * FROM carrera");
        $consult->execute();
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }
    public function getDepartamento($id)
    {
        $consult = $this->pdo->prepare("SELECT * FROM departamento WHERE IdDepartamento = ?");
        $consult->execute([$id]);
        return $consult->fetch(PDO::FETCH_ASSOC);
    }

    public function getDatos($table)
    {
        $consult = $this->pdo->prepare("SELECT * FROM $table");
        $consult->execute();
        return $consult->fetchAll(PDO::FETCH_ASSOC);
    }

    public function comprobarDepartamento($nombre_d, $accion)
    {
        if ($accion == 0) {
            $consult = $this->pdo->prepare("SELECT * FROM departamento WHERE Nombre = ?");
            $consult->execute([$nombre_d]);
        } else {
            $consult = $this->pdo->prepare("SELECT * FROM departamento WHERE Nombre = ? AND IdDepartamento != ?");
            $consult->execute([$nombre_d, $accion]);
        }
        return $consult->fetch(PDO::FETCH_ASSOC);
    }

    public function save($nombre_d)
    {
        $consult = $this->pdo->prepare("INSERT INTO departamento (Nombre) VALUES (?)");
        return $consult->execute([$nombre_d]);
    }

    public function update($nombre_d, $id)
    {
        $consult = $this->pdo->prepare("UPDATE departamento SET Nombre=? WHERE IdDepartamento=?");
        return $consult->execute([$nombre_d, $id]);
    }

    public function delete($id)
    {
        $consult = $this->pdo->prepare("DELETE FROM departamento WHERE IdDepartamento = ?");
        return $consult->execute([$id]);
    }
}
