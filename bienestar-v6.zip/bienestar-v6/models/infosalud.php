<?php
require_once '../config.php';
require_once 'conexion.php';
class InfoSaludModel{
    private $pdo, $con;
    public function __construct() {
        $this->con = new Conexion();
        $this->pdo = $this->con->conectar();
    }
    
    public function getIdAlumno($iduser)
    {
        $consult = $this->pdo->prepare("SELECT info_alumno.IdAlumno as idalumno FROM usuario INNER JOIN info_alumno ON usuario.IdUsuario=info_alumno.IdUsuario WHERE usuario.IdUsuario= ?");
        $consult->execute([$iduser]);
        return $consult->fetch(PDO::FETCH_ASSOC);
    }

    public function save($seguro_is, $tiposeguro_is, $parientecontacto_is, $numerocontacto_is, $usted_is_ps, $usteddetalle_is_ps, $padre_is_ps, $padredetalle_is_ps, $madre_is_ps, $madredetalle_is_ps, $hermano_is_ps, $hermanodetalle_is_ps, $otro_is_ps, $otrodetalle_is_ps, $usted_is_d, $usteddetalle_is_d, $padre_is_d, $padredetalle_is_d, $madre_is_d, $madredetalle_is_d, $hermano_is_d, $hermanodetalle_is_d, $otro_is_d, $otrodetalle_is_d, $idalumno_is)
    {
        $consult = $this->pdo->prepare("INSERT INTO info_salud (Seguro, TipoSeguro, ParienteContacto, NumeroContacto, PSUsted, PSUstedDetalle, PSPadre, PSPadreDetalle, PSMadre, PSMadreDetalle, PSHermano, PSHermanoDetalle, PSOtro, PSOtroDetalle, DUsted, DUstedDetalle, DPadre, DPadreDetalle, DMadre, DMadreDetalle, DHermano, DHermanoDetalle, DOtro, DOtroDetalle, IdAlumno) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        return $consult->execute([$seguro_is, $tiposeguro_is, $parientecontacto_is, $numerocontacto_is, $usted_is_ps, $usteddetalle_is_ps, $padre_is_ps, $padredetalle_is_ps, $madre_is_ps, $madredetalle_is_ps, $hermano_is_ps, $hermanodetalle_is_ps, $otro_is_ps, $otrodetalle_is_ps, $usted_is_d, $usteddetalle_is_d, $padre_is_d, $padredetalle_is_d, $madre_is_d, $madredetalle_is_d, $hermano_is_d, $hermanodetalle_is_d, $otro_is_d, $otrodetalle_is_d, $idalumno_is]);
    }  


}