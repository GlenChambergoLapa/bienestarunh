<?php
require_once '../config.php';
require_once 'conexion.php';
class InfoViviendaModel{
    private $pdo, $con;
    public function __construct() {
        $this->con = new Conexion();
        $this->pdo = $this->con->conectar();
    }
    
    public function getIdAlumno($iduser)
    {
        $consult = $this->pdo->prepare("SELECT info_alumno.IdAlumno as idalumno FROM usuario INNER JOIN info_alumno ON usuario.IdUsuario=info_alumno.IdUsuario WHERE usuario.IdUsuario= ?");
        $consult->execute([$iduser]);
        return $consult->fetch(PDO::FETCH_ASSOC);
    }

   
    public function save($viveen_iv, $otrosviveen_iv, $material_iv, $otrosmat_iv, $estado_iv, $datoscheckboxservicio_iv, $datoscheckboxequipamiento_iv, $idalumno_iv)
    {
        $consult = $this->pdo->prepare("INSERT INTO info_vivienda (ViveEn, Otroviveen, Material, Otromat, Estado, Servicio, Equipamiento, IdAlumno) VALUES (?,?,?,?,?,?,?,?)");
        return $consult->execute([$viveen_iv, $otrosviveen_iv, $material_iv, $otrosmat_iv, $estado_iv, $datoscheckboxservicio_iv, $datoscheckboxequipamiento_iv, $idalumno_iv]);
    }  


}
