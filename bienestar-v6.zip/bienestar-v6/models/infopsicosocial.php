<?php
require_once '../config.php';
require_once 'conexion.php';
class InfoPsicosocialModel{
    private $pdo, $con;
    public function __construct() {
        $this->con = new Conexion();
        $this->pdo = $this->con->conectar();
    }
    
    public function getIdAlumno($iduser)
    {
        $consult = $this->pdo->prepare("SELECT info_alumno.IdAlumno as idalumno FROM usuario INNER JOIN info_alumno ON usuario.IdUsuario=info_alumno.IdUsuario WHERE usuario.IdUsuario= ?");
        $consult->execute([$iduser]);
        return $consult->fetch(PDO::FETCH_ASSOC);
    }

   
    public function save($economico_ap, $alimentacion_ap, $vivienda_ap, $transporte_ap, $familiar_ap, $psicologico_ap, $consumealcohol_ap, $parentesco_ap, $existeviolencia_ap, $especifique_ap, $datoscheckboxpuniversidad_ap, $datoscheckboxpvives_ap, $idalumno_ap)
    {
        $consult = $this->pdo->prepare("INSERT INTO info_psicosocial (PEconomico, PAlimentacion, PVivienda, PTransporte, PFamiliar, PPsicologico, Alcohol, ParentescoAlcohol, Violencia, DetalleViolencia, PUniversidad, PVive, IdAlumno) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
        return $consult->execute([$economico_ap, $alimentacion_ap, $vivienda_ap, $transporte_ap, $familiar_ap, $psicologico_ap, $consumealcohol_ap, $parentesco_ap, $existeviolencia_ap, $especifique_ap, $datoscheckboxpuniversidad_ap, $datoscheckboxpvives_ap, $idalumno_ap]);
    }  


}
