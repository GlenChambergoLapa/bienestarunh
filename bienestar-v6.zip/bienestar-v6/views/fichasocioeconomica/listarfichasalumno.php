<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover" style="width: 100%;" id="table_listafichaalumno">
                <thead>
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Nombres y Apellidos</th>
                        <th scope="col">DNI</th>
                        <th scope="col">Ficha S.</th>
                    </tr>
                </thead>
                <tbody>

                </tbody>
            </table>
        </div>
    </div>
</div>