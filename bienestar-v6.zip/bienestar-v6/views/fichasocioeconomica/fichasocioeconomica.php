<!-- I. DATOS GENERALES -->
<form id="frmInfoAlumno" method="POST" autocomplete="off">
    <div class="card mb-2" id='formdatosgenerales'>
        <div class="card-header">
            <h3 class="card-title">I. DATOS GENERALES</h3>
        </div>
        <div class="card-body">
            <input type="hidden" id="id_alumno_dg" name="id_alumno_dg">

            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="nombres_dg">NOMBRES: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="nombres_dg" name="nombres_dg" placeholder="Nombres" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="apellidopaterno_dg">APELLIDO PATERNO: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="apellidopaterno_dg" name="apellidopaterno_dg" placeholder="Apellido Paterno" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="apellidomaterno_dg">APELLIDO MATERNO: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="apellidomaterno_dg" name="apellidomaterno_dg" placeholder="Apellido Materno" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group mb-3">
                        <label for="fechadenacimiento_dg">FECHA DE NACIMIENTO: <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="fechadenacimiento_dg" name="fechadenacimiento_dg" required>
                    </div>
                </div>
            </div>

            <div class="row">                
                <div class="col-md-2">
                    <div class="form-group mb-3">
                        <label for="edad_dg">EDAD: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="edad_dg" name="edad_dg" maxlength="2" placeholder="Edad">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="genero_dg">GENERO: <span class="text-danger">*</span></label>
                        <select class="form-control" id="genero_dg" name="genero_dg">
                            <option value="">Seleccionar():</option>
                            <option value="MASCULINO">MASCULINO</option>
                            <option value="FEMENINO">FEMENINO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="dni_dg">DNI: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="dni_dg" name="dni_dg" maxlength="8" placeholder="Dni">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="telefonocelular_dg">TELÉFONO/CELULAR: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="telefonocelular_dg" name="telefonocelular_dg" maxlength="9" placeholder="Telefono/Celular">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="correo_dg">CORREO: <span class="text-danger">*</span></label>
                        <input type="email" class="form-control" id="correo_dg" name="correo_dg" placeholder="Correo">
                    </div>
                </div>
            </div>
            
            <div class="row">                
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="domicilioactual_dg">DOMICILIO ACTUAL: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="domicilioactual_dg" name="domicilioactual_dg" placeholder="Domicilio Actual">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="departamentoda_dg">DEPARTAMENTO: <span class="text-danger">*</span></label>
                        <select class="form-control" id="departamentoda_dg" name="departamentoda_dg">
                        </select>

                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="provinciada_dg">PROVINCIA: <span class="text-danger">*</span></label>
                        <select class="form-control" id="provinciada_dg" name="provinciada_dg">
                            <option value="">Seleccionar():</option>
                        </select>

                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="distritoda_dg">DISTRITO: <span class="text-danger">*</span></label>
                        <select class="form-control" id="distritoda_dg" name="distritoda_dg">
                            <option value="">Seleccionar():</option>
                        </select>

                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <label for="anexoda_dg">ANEXO: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="anexoda_dg" name="anexoda_dg" placeholder="Anexo">
                    </div>
                </div>
            </div>

            <div class="row"> 
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="referenciadomicilio_dg">REFERENCIA DEL DOMICILIO: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="referenciadomicilio_dg" name="referenciadomicilio_dg" placeholder="Referencia De Su Domicilio">
                    </div>
                </div>
            </div>

            <div class="row">                
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="lugarnacimiento_dg">LUGAR DE NACIMIENTO: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="lugarnacimiento_dg" name="lugarnacimiento_dg" placeholder="Lugar de Nacimiento">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="departamentoln_dg">DEPARTAMENTO: <span class="text-danger">*</span></label>
                        <select class="form-control" id="departamentoln_dg" name="departamentoln_dg">
                        </select>

                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="provincialn_dg">PROVINCIA: <span class="text-danger">*</span></label>
                        <select class="form-control" id="provincialn_dg" name="provincialn_dg">
                            <<option value="">Seleccionar():</option>
                        </select>

                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="distritoln_dg">DISTRITO: <span class="text-danger">*</span></label>
                        <select class="form-control" id="distritoln_dg" name="distritoln_dg">
                            <<option value="">Seleccionar():</option>
                        </select>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="anexoln_dg">ANEXO: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="anexoln_dg" name="anexoln_dg" placeholder="Anexo">
                    </div>
                </div>
            </div>

            <div class="row">                
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="estadocivil_dg">ESTADO CIVIL: <span class="text-danger">*</span></label>
                        <select class="form-control" id="estadocivil_dg" name="estadocivil_dg">
                            <option value="">Seleccionar():</option>
                            <option value="SOLTERO">Soltero</option>
                            <option value="CASADO">Casado</option>
                            <option value="CONVIVIENTE">Conviviente</option>
                        </select>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="numerohijos_dg">NRO. DE HIJOS: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="numerohijos_dg" name="numerohijos_dg" maxlength="2" placeholder="Nro. De Hijos">
                    </div>
                </div>
            </div>

        </div>
        <div class="card-footer text-end">
            <button type="button" class="btn btn-danger" id="btn-nuevo-dg">Nuevo</button>
            <button type="submit" class="btn btn-primary" id="btn-save-dg" name="btnguardardatosgenerales">Guardar</button>
        </div>
    </div>
</form>

<!-- II. ASPECTO ACADEMICO -->
<form id="frmInfoAcademica" method="POST" autocomplete="off">
    <div class="card mb-2" id='formaspectoacademico'>
        <div class="card-header">
            <h3 class="card-title">II. ASPECTO ACADEMICO</h3>
        </div>
        <div class="card-body">
            <input type="hidden" id="id_alumno_aa" name="id_alumno_aa">

            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="carrera_aa">ESCUELA PROFESIONAL: <span class="text-danger">*</span></label>
                        <select class="form-control" id="carrera_aa" name="carrera_aa">
                        </select>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="codigomatricula_aa">CÓDIGO DE MATRICULA: <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="codigomatricula_aa" name="codigomatricula_aa" placeholder="Codigo de matricula" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="ciclo_aa">CICLO: <span class="text-danger">*</span></label>
                        <select class="form-control" id="ciclo_aa" name="ciclo_aa">
                            <option value="">Seleccionar():</option>
                            <option value="I">I CICLO</option>
                            <option value="II">II CICLO</option>
                            <option value="III">III CICLO</option>
                            <option value="IV">IV CICLO</option>
                            <option value="V">V CICLO</option>
                            <option value="VI">VI CICLO</option>
                            <option value="VII">II CICLO</option>
                            <option value="VIII">VIII CICLO</option>
                            <option value="IX">IX CICLO</option>
                            <option value="X">X CICLO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group mb-3">
                        <label for="segundacarrera_aa">2da CARRERA: <span class="text-danger">*</span></label>
                        <select class="form-control" id="segundacarrera_aa" name="segundacarrera_aa">
                            <option value="">Seleccionar():</option>
                            <option value="SI">SI</option>
                            <option value="NO">NO</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="row">                
                <div class="col-md-4">
                    <div class="form-group mb-3">
                        <label for="promedioponderado_aa">PROMEDIO PONDERADO DEL CICLO ANTERIOR: <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="promedioponderado_aa" name="promedioponderado_aa" placeholder="Promedio ponderado del ciclo anterior">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="numcursosdesaprobados_aa">N° DE CURSO DESAPROBADO DEL CICLO ANTERIOR: <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="numcursosdesaprobados_aa" name="numcursosdesaprobados_aa" placeholder="Nro. de curso desaprobado de ciclo anterior">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="numcursoacargo_aa">N° DE CURSOS A CARGO: <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="numcursoacargo_aa" name="numcursoacargo_aa" placeholder="Nro. de curso a cargo">
                    </div>
                </div>
            </div>

            <div class="row">  
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="modalidadingreso_aa">MODALIDAD DE INGRESO A LA UNH: <span class="text-danger">*</span></label>
                        <select class="form-control" id="modalidadingreso_aa" name="modalidadingreso_aa">
                            <option value="">Seleccionar():</option>
                            <option value="Examen Ordinario">Examen Ordinario</option>
                            <option value="Cepre UNH">Cepre UNH</option>
                            <option value="Convenio">Convenio</option>
                            <option value="Segunda Carrera">Segunda Carrera</option>
                            <option value="Deportista Destacado">Deportista Destacado</option>
                            <option value="Persona Discapacidad">Persona Discapacidad</option>
                            <option value="Víctima de Violencia Política">Víctima de Violencia Política</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="abandonoestudios_aa">ABANDONÓ SUS ESTUDIOS: <span class="text-danger">*</span></label>
                        <select class="form-control" id="abandonoestudios_aa" name="abandonoestudios_aa">
                            <option value="">Seleccionar():</option>
                            <option value="NO">NO</option>
                            <option value="SI">SI</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="motivo_aa">MOTIVO: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="motivo_aa" name="motivo_aa" placeholder="Motivo">
                    </div>
                </div>
            </div>
           
        </div>
        <div class="card-footer text-end">
            <button type="button" class="btn btn-danger" id="btn-nuevo-aa">Nuevo</button>
            <button type="submit" class="btn btn-primary" id="btn-save-aa">Guardar</button>
        </div>
    </div>
</form>

<!-- III. INFO FAMILIA -->
<form id="frmInfoFamilia" method="POST" autocomplete="off">
    <div class="card mb-2" id='forminfofamilia'>
        <div class="card-header">
            <h3 class="card-title">III. ASPECTO FAMILIA</h3>
        </div>
        <div class="card-body">
            <input type="hidden" id="id_alumno_af" name="id_alumno_af">

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="padres_af">PADRES: <span class="text-danger">*</span></label>
                        <select class="form-control" id="padres_af" name="padres_af">
                            <option value="">Seleccionar():</option>
                            <option value="Casados">Casados</option>
                            <option value="Convivientes">Convivientes</option>
                            <option value="Separados">Separados</option>
                            <option value="Divorciados">Divorciados</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="orfandad_af">ORFANDAD: <span class="text-danger">*</span></label>
                        <select class="form-control" id="orfandad_af" name="orfandad_af">
                            <option value="">Seleccionar():</option>
                            <option value="Parcial">Parcial</option>
                            <option value="Total">Total</option>
                            <option value="N.A.">N.A.</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="viveactualmentecon_af">VIVE ACTUALMENTE CON: <span class="text-danger">*</span></label>
                    </div> 
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label><input type="checkbox" name="viveactual_af[]" value="Ambos Padres">AMBOS PADRES</label>    
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                    <label><input type="checkbox" name="viveactual_af[]" value="padres">PADRE</label>
                           
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                    <label><input type="checkbox" name="viveactual_af[]" value="madre">MADRE</label>
                           
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                    <label><input type="checkbox" name="viveactual_af[]" value="hermanos">HERMANOS</label>
                           
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                    <label><input type="checkbox" name="viveactual_af[]" value="solo">SOLO</label>
                           
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                    <label><input type="checkbox" name="viveactual_af[]" value="conyugue">CONYUGUE</label>
                           
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="otrosespecifique_af">OTROS ESPECIFIQUE: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="otrosespecifique_af" name="otrosespecifique_af" placeholder="Otros Especifique" autocomplete="off">
                    </div>
                </div>    
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="numerodehermanos_af">N° DE HERMANOS QUE DEPENDEN DE LOS PADRES: <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="numerodehermanos_af" name="numerodehermanos_af" placeholder="Número de Hermanos" autocomplete="off">
                    </div>
                </div>    
            </div>

            <div class="row">
                <div class="form-group">
                    <button type="button" class="btn btn-danger" id="btn-agregar-ifamiliar">Agregar</button>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-hover" style="width: 100%;" id="table_estructurafamiliar_af" cellspacing="0">
                        <thead>
                            <tr>
                                <th>APELLIDOS Y NOMBRES</th>
                                <th>EDAD</th>
                                <th>SEXO</th>
                                <th>PARENTESCO</th>
                                <th>N° DE CELULAR</th>
                                <th>EST. CIVIL</th>
                                <th>GRADO INSTRUC.</th>
                                <th>OCUPACIÓN</th>
                                <th>INGRESO SEMANAL S/.</th>
                            </tr>
                        </thead>
                        
                    </table>

                </div>    
            </div>
            
            <div class="card-footer text-end">
                <button type="button" class="btn btn-danger" id="btn-nuevo-af">Nuevo</button>
                <button type="submit" class="btn btn-primary" id="btn-save-af">Guardar</button>
            </div>
        </div>
    </div>
</form>

<!-- IV. INFO_ECONOMICO -->
<form id="frmInfoEconomica" method="POST" autocomplete="off">
    <div class="card mb-2">
        <div class="card-header">
            <h3 class="card-title">IV. ASPECTO ECONÓMICO</h3>
        </div>
        <div class="card-body">
            <input type="hidden" id="id_alumno_ie" name="id_alumno_ie">

            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="dependencia_ie">DEPENDE ECONOMICAMENTE DE: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="dependencia_ie" id="dependencia_ie">
                            <option value="">Seleccionar():</option>
                            <option value="AMBOS PADRES">AMBOS PADRES</option>
                            <option value="SOLO PAPA">SOLO PAPÁ</option>
                            <option value="SOLO MAMA">SOLO MAMÁ</option>
                            <option value="HERMANOS">HERMANOS</option>
                            <option value="CONYUGUE">CONYUGUE</option>
                            <option value="DE SI MISMO">DE SÍ MISMO</option>
                            <option value="OTRO">OTRO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="otrosespecifique_ie">OTROS ESPECIFIQUE: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="otrosespecifique_ie" name="otrosespecifique_ie" placeholder="Otros Especifique" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="ingresofamsemanal_ie">INGRESO FAMILIAR SEMANAL (S/.): <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="ingresofamsemanal_ie" name="ingresofamsemanal_ie" placeholder="Ingreso familiar semanal en soles" autocomplete="off">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                    <label for="actividadeconomica_ie">USTED DESEMPEÑA ALGUNA ACTIVIDAD ECONÓMICA: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="actividadeconomica_ie" id="actividadeconomica_ie">
                            <option value="">Seleccionar():</option>
                            <option value="SI">SÍ</option>
                            <option value="NO">NO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="especifique_ie">ESPECIFIQUE: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="especifique_ie" id="especifique_ie">
                            <option value="">Seleccionar():</option>
                            <option value="CONTRATADO">CONTRATADO</option>
                            <option value="INDEPENDIENTE">INDEPENDIENTE</option>
                            <option value="EVENTUAL">EVENTUAL</option>
                            <option value="DESEMPLEADO">DESEMPLEADO</option>
                        </select>
                     </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="ingresosemanal_ie">INGRESO SEMANAL: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="ingresosemanal_ie" name="ingresosemanal_ie" placeholder="Solo si usted desempeña alguna actividad económica" autocomplete="off">
                    </div>
                </div>
            </div>
        </div> 
        <div class="card-footer text-end">
            <button type="button" class="btn btn-danger" id="btn-nuevo-ie">Nuevo</button>
            <button type="submit" class="btn btn-primary" id="btn-save-ie">Guardar</button>
        </div>    
    </div>
</form>

<!-- V. INFO_VIVIENDA -->
<form id="frmInfoVivienda" method="POST" autocomplete="off">
    <div class="card mb-2" id="forminfovivienda">
        <div class="card-header">
            <h3 class="card-title">V. ASPECTO VIVIENDA</h3>
        </div>
        <div class="card-body">
            <input type="hidden" id="id_alumno_iv" name="id_alumno_iv">

            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="viveen_iv">VIVE EN: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="viveen_iv" id="viveen_iv">
                            <option value="">Seleccionar():</option>
                            <option value="CASA PROPIA">CASA PROPIA</option>
                            <option value="ALQUILADA">ALQUILADA</option>
                            <option value="ALOJADO">ALOJADO</option>
                            <option value="RESIDENCIA UNIVERSITARI">RESIDENCIA UNIVERSITARIA</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="otrosviveen_iv">OTROS ESPECIFIQUE: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="otrosviveen_iv" name="otrosviveen_iv" placeholder="Otros Especifique" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="material_iv">MATERIAL DE CONSTRUCCIÓN: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="material_iv" id="material_iv">
                            <option value="">Seleccionar():</option>
                            <option value="LADRILLO">LADRILLO</option>
                            <option value="RUSTICO/ADOBE/TAPIA">RUSTICO/ADOBE/TAPIA</option>
                            <option value="MIXTO">MIXTO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="otrosmat_iv">OTROS ESPECIFIQUE: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="otrosmat_iv" name="otrosmat_iv" placeholder="Otros Especifique" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="estado_iv">ESTADO DE CONSTRUCCIÓN: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="estado_iv" id="estado_iv">
                            <option value="">Seleccionar():</option>
                            <option value="ACABADO">ACABADO</option>
                            <option value="EN CONSTRUCCIÓN">EN CONSTRUCCIÓN</option>
                        </select>
                    </div>
                </div>
            </div>


            <div class="row">
               
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="servicio_iv">SERVICIO DE VIVIENDA: <span class="text-danger">*</span></label>
                    </div>
                </div>
            </div>


            <div class="row">
               
                <div class="col-md-1">
                    <div class="form-group">
                        <label><input type="checkbox"  name="servicio_iv[]" value="LUZ"> LUZ</label>
                    </div>
                </div>
                <div class="col-md-1">
                    <div class="form-group">
                        <label><input type="checkbox"  name="servicio_iv[]" value="AGUA"> AGUA</label>
                    </div>
                </div>
                <div class="col-md-1">
                    <div class="form-group">
                        <label><input type="checkbox"  name="servicio_iv[]" value="DESAGUE"> DESAGUE</label>
                    </div>
                </div>
                <div class="col-md-1">
                    <div class="form-group">
                        <label><input type="checkbox"  name="servicio_iv[]" value="INTERNET"> INTERNET</label>
                    </div>
                </div>
                <div class="col-md-1">
                    <div class="form-group">
                        <label><input type="checkbox"  name="servicio_iv[]" value="TVCABLE"> TV CABLE</label>
                    </div>
                </div>
            </div>
            <div class="row">
               
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="equipamiento_iv">EN EL CUARTO O CASA DONDE VIVES CUENTA CON: <span class="text-danger">*</span></label>
                    </div>
                </div>
            </div>
            <div class="row">
               
                <div class="col-md-3">
                    <div class="form-group">
                        <label><input type="checkbox"  name="equipamiento_iv[]" value="REFRIGERADORA"> REFRIGERADORA</label>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label><input type="checkbox"  name="equipamiento_iv[]" value="TELEVISION-COMPUTADORA"> TELEVISION-COMPUTADORA</label>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label><input type="checkbox"  name="equipamiento_iv[]" value="OLLAARROCERA"> OLLA ARROCERA</label>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label><input type="checkbox"  name="equipamiento_iv[]" value="LICUADORA"> LICUADORA</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label><input type="checkbox"  name="equipamiento_iv[]" value="HERVIDORA"> HERVIDORA</label>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label><input type="checkbox"  name="equipamiento_iv[]" value="MICROONDAS"> MICROONDAS</label>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label><input type="checkbox"  name="equipamiento_iv[]" value="LAVADORA"> LAVADORA</label>
                    </div>
                </div>
            </div>




        </div>
        <div class="card-footer text-end">
            <button type="button" class="btn btn-danger" id="btn-nuevo-iv">Nuevo</button>
            <button type="submit" class="btn btn-primary" id="btn-save-iv">Guardar</button>
        </div>
    </div>
</form>

<!-- VI. INFO_ALIMENTACION -->
<form id="frmInfoAlimentacion" method="POST" autocomplete="off">
    <div class="card mb-2" id="forminfoalimentacion">
        <div class="card-header">
            <h3 class="card-title">VI. ASPECTO ALIMENTACION</h3>
        </div>
        <div class="card-body">
            <input type="hidden" id="id_alumno_ia" name="id_alumno_ia">

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="cocinacasa_ia">¿COCINA EN SU CASA O CUARTO?: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="cocinacasa_ia" id="cocinacasa_ia">
                            <option value="">Seleccionar():</option>
                            <option value="SI">SI</option>
                            <option value="NO">NO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="detalle_ia">ESPECIFIQUE: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="detalle_ia" name="detalle_ia" placeholder="Detalle" autocomplete="off">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="tipococina_ia">PREPARA TUS ALIMENTOS: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="tipococina_ia" id="tipococina_ia">
                            <option value="">Seleccionar():</option>
                            <option value="Cocina a Gas">Cocina a Gas</option>
                            <option value="Cocina a Leña">Cocina a Leña</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="comedoruniv_ia">TUVO ACCESO A COMEDOR UNIVERSITARIO CICLOS ANTERIORES: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="comedoruniv_ia" id="comedoruniv_ia">
                            <option value="">Seleccionar():</option>
                            <option value="SI">SI</option>
                            <option value="NO">NO</option>
                        </select>
                    </div>
                </div>
            </div>

        </div>
        <div class="card-footer text-end">
            <button type="button" class="btn btn-danger" id="btn-nuevo-ia">Nuevo</button>
            <button type="submit" class="btn btn-primary" id="btn-save-ia">Guardar</button>
        </div>
    </div>
</form>

<!-- VII. INFO_SALUD -->
<form id="frmInfoSalud" method="POST" autocomplete="off">
    <div class="card mb-2" id="forminfosalud">
        <div class="card-header">
            <h3 class="card-title">VII. ASPECTO SALUD</h3>
        </div>
        <div class="card-body">
            <input type="hidden" id="id_alumno_is" name="id_alumno_is">

            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="seguro_is">TIENE SEGURO DE SALUD: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="seguro_is" id="seguro_is">
                            <option value="">Seleccionar():</option>
                            <option value="SI">SI</option>
                            <option value="NO">NO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="tiposeguro_is">TIPO DE SEGURO: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="tiposeguro_is" name="tiposeguro_is" placeholder="Solo si cuenta con algún seguro" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="parientecontacto_is">FAMILIA DE CONTACTO POR EMERGENCIA: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="parientecontacto_is" name="parientecontacto_is" placeholder="Nombre y parentezco del familiar" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="numerocontacto_is">TELEFONO DE EMERGENCIA: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="numerocontacto_is" name="numerocontacto_is" placeholder="Número telefónico de su familiar" autocomplete="off">
                    </div>
                </div>
            </div>
            
            <A4><B>PROBLEMA DE SALUD DE SUS FAMILIARES</B></A4><BR><BR>
            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="usted_is_ps">USTED: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="usted_is_ps" id="usted_is_ps">
                            <option value="">Seleccionar():</option>
                            <option value="SI">SI</option>
                            <option value="NO">NO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="form-group">
                        <label for="usteddetalle_is_ps">ESPECIFIQUE: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="usteddetalle_is_ps" name="usteddetalle_is_ps" placeholder="Solo si la respuesta fué SI" autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="padre_is_ps">SU PADRE: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="padre_is_ps" id="padre_is_ps">
                            <option value="">Seleccionar():</option>
                            <option value="SI">SI</option>
                            <option value="NO">NO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="form-group">
                        <label for="padredetalle_is_ps">ESPECIFIQUE: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="padredetalle_is_ps" name="padredetalle_is_ps" placeholder="Solo si la respuesta fué SI" autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="madre_is_ps">SU MADRE: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="madre_is_ps" id="madre_is_ps">
                            <option value="">Seleccionar():</option>
                            <option value="SI">SI</option>
                            <option value="NO">NO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="form-group">
                        <label for="madredetalle_is_ps">ESPECIFIQUE: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="madredetalle_is_ps" name="madredetalle_is_ps" placeholder="Solo si la respuesta fué SI" autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="hermano_is_ps">SU HERMANO: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="hermano_is_ps" id="hermano_is_ps">
                            <option value="">Seleccionar():</option>
                            <option value="SI">SI</option>
                            <option value="NO">NO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="form-group">
                        <label for="hermanodetalle_is_ps">ESPECIFIQUE: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="hermanodetalle_is_ps" name="hermanodetalle_is_ps" placeholder="Solo si la respuesta fué SI" autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="otro_is_ps">OTRO: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="otro_is_ps" id="otro_is_ps">
                            <option value="">Seleccionar():</option>
                            <option value="SI">SI</option>
                            <option value="NO">NO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="form-group">
                        <label for="otrodetalle_is_ps">ESPECIFIQUE: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="otrodetalle_is_ps" name="otrodetalle_is_ps" placeholder="Solo si la respuesta fué SI" autocomplete="off">
                    </div>
                </div>
            </div>


            <A4><B>DISCAPACIDAD DE ALGÚN FAMILIAR</B></A4><BR><BR>
            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="usted_is_d">USTED: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="usted_is_d" id="usted_is_d">
                            <option value="">Seleccionar():</option>
                            <option value="SI">SI</option>
                            <option value="NO">NO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="form-group">
                        <label for="usteddetalle_is_d">ESPECIFIQUE: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="usteddetalle_is_d" name="usteddetalle_is_d" placeholder="Solo si la respuesta fué SI" autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="padre_is_d">SU PADRE: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="padre_is_d" id="padre_is_d">
                            <option value="">Seleccionar():</option>
                            <option value="SI">SI</option>
                            <option value="NO">NO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="form-group">
                        <label for="padredetalle_is_d">ESPECIFIQUE: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="padredetalle_is_d" name="padredetalle_is_d" placeholder="Solo si la respuesta fué SI" autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="madre_is_d">SU MADRE: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="madre_is_d" id="madre_is_d">
                            <option value="">Seleccionar():</option>
                            <option value="SI">SI</option>
                            <option value="NO">NO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="form-group">
                        <label for="madredetalle_is_d">ESPECIFIQUE: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="madredetalle_is_d" name="madredetalle_is_d" placeholder="Solo si la respuesta fué SI" autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="hermano_is_d">SU HERMANO: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="hermano_is_d" id="hermano_is_d">
                            <option value="">Seleccionar():</option>
                            <option value="SI">SI</option>
                            <option value="NO">NO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="form-group">
                        <label for="hermanodetalle_is_d">ESPECIFIQUE: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="hermanodetalle_is_d" name="hermanodetalle_is_d" placeholder="Solo si la respuesta fué SI" autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="otro_is_d">OTRO: <span class="text-danger">*</span></label>
                        <select class = "form-control" name="otro_is_d" id="otro_is_d">
                            <option value="">Seleccionar():</option>
                            <option value="SI">SI</option>
                            <option value="NO">NO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="form-group">
                        <label for="otrodetalle_is_d">ESPECIFIQUE: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="otrodetalle_is_d" name="otrodetalle_is_d" placeholder="Solo si la respuesta fué SI" autocomplete="off">
                    </div>
                </div>
            </div>
        </div> 
        <div class="card-footer text-end">
            <button type="button" class="btn btn-danger" id="btn-nuevo-is">Nuevo</button>
            <button type="submit" class="btn btn-primary" id="btn-save-is">Guardar</button>
        </div>    
    </div>
</form>

<!-- VIII. INFO PSICOSOCIAL -->
<form id="frmInfoSocial" method="POST" autocomplete="off">
    <div class="card mb-2">
        <div class="card-header">
            <h3 class="card-title">VIII. ASPECTO PSICOSOCIAL</h3>
        </div>
        <div class="card-body">
            <input type="hidden" id="id_alumno_ap" name="id_alumno_ap">

            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="queproblemaspresentaactualmente_ap"> ¿ QUÉ PROBLEMAS PRESENTA ACTUALMENTE ? DESCRIBIR: <span class="text-danger">*</span></label>
                       
                    </div>
                </div>
               
            </div>
           
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="economico_ap">ECONÓMICO: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="economico_ap" name="economico_ap" placeholder="Economico" autocomplete="off">
                    </div>
                </div>    
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="alimentacion_ap">ALIMENTACIÓN: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="alimentacion_ap" name="alimentacion_ap" placeholder="Alimentación" autocomplete="off">
                    </div>
                </div>    
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="vivienda_ap">VIVIENDA: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="vivienda_ap" name="vivienda_ap" placeholder="Vivienda" autocomplete="off">
                    </div>
                </div>    
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="transporte_ap">TRANSPORTE: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="transporte_ap" name="transporte_ap" placeholder="Transporte" autocomplete="off">
                    </div>
                </div>    
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="familiar_ap">FAMILIAR: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="familiar_ap" name="familiar_ap" placeholder="Familiar" autocomplete="off">
                    </div>
                </div>    
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="psicologico_ap">PISICOLÓGICO: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="psicologico_ap" name="psicologico_ap" placeholder="Psicologico" autocomplete="off">
                    </div>
                </div>    
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="consumealcohol_ap">¿ TIENES ALGÚN FAMILIAR QUE CONSUME ALCOHOL FRECUENTEMENTE ? <span class="text-danger">*</span></label>
                        <select class = "form-control" name="consumealcohol_ap" id="consumealcohol_ap">
                            <option value="">Seleccionar():</option>
                            <option value="SI">SI</option>
                            <option value="NO">NO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="parentesco_ap">PARENTESCO: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="parentesco_ap" name="parentesco_ap" placeholder="Parentezco" autocomplete="off">
                    </div>
                   
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="existeviolencia_ap">¿ EXISTE MALTRATO O VIOLENCIA EN TU FAMILIA ? <span class="text-danger">*</span></label>
                        <select class = "form-control" name="existeviolencia_ap" id="existeviolencia_ap">
                            <option value="">Seleccionar():</option>
                            <option value="SI">SI</option>
                            <option value="NO">NO</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="especifique_ap">ESPECIFIQUE: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="especifique_ap" name="especifique_ap" placeholder="Especifique" autocomplete="off">
                    </div>
                   
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="problemassocialesuniversidad_ap">¿QUÉ PROBLEMAS SOCIALES HAS IDENTIFICADO EN LA UNIVERSIDAD? <span class="text-danger">*</span></label>
                    </div>
                   
                </div>
            </div>

            <div class="row">
                <div class="col-md-2">
                    <div class="form-group">
                        <label><input type="checkbox"  name="puniversidad_ap[]" value="Bullyng">BULLYNG</label>
                           
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                    <label><input type="checkbox"  name="puniversidad_ap[]" value="Alcoholismo">ALCOHOLISMO</label>
                           
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                    <label><input type="checkbox"  name="puniversidad_ap[]" value="Drogadiccion">DROGADICCIÓN</label>
                           
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                    <label><input type="checkbox"  name="puniversidad_ap[]" value="Embarazo no deseado">EMBARAZO NO DESEADO</label>
                           
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                    <label><input type="checkbox"  name="puniversidad_ap[]" value="Delincuencia">DELINCUENCIA</label>
                           
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                    <label><input type="checkbox"  name="puniversidad_ap[]" value="Discriminacion">DISCRIMINACIÓN</label>
                           
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="otrosuniv_ap">OTROS: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="puniversidad_ap[]" placeholder="Otros" autocomplete="off">
                    </div>
                   
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="problemasidentificadocasa_ap">¿QUÉ PROBLEMAS SOCIALES HAS IDENTIFICADO POR EL LUGAR DONDE VIVES? <span class="text-danger">*</span></label>
                    </div>
                   
                </div>
               
                <div class="col-md-3">
                    <div class="form-group">
                    <label><input type="checkbox"  name="pvives_ap[]" value="Alcoholismo">ALCOHOLISMO</label>
                           
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                    <label><input type="checkbox"  name="pvives_ap[]" value="Drogadiccion">DROGADICCIÓN</label>
                           
                    </div>
                </div>
               
                <div class="col-md-3">
                    <div class="form-group">
                    <label><input type="checkbox"  name="pvives_ap[]" value="Delincuencia">DELINCUENCIA</label>
                           
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                    <label><input type="checkbox"  name="pvives_ap[]" value="Pandillaje">PANDILLAJE</label>
                           
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="otrosviv_ap">OTROS: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control"  name="pvives_ap[]" placeholder="Otros" autocomplete="off">
                    </div>
                   
                </div>

                <div class="card-footer text-end">
                    <button type="button" class="btn btn-danger" id="btn-nuevo-ap">Nuevo</button>
                     <button type="submit" class="btn btn-primary" id="btn-save-ap">Guardar</button>
                </div>
               
               
            </div>
         
        </div>    
    </div>
</form>

<!-- Modal Para Agregar Infraestructura familiar -->

<div class="modal fade" id="modalEstructuraFamiliar" style="display: none;" aria-hidden="true">
    <form id="formAgregarFamiliar" enctype="multipart/form-data" method="post">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><b>Agregar Familiar</b></h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="nombres_af_m">NOMBRES: <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="nombres_af_m" name="nombres_af_m" placeholder="Nombres" autocomplete="off">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                            <label for="apepat_af_m">APELLIDO PATERNO: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="apepat_af_m" name="apepat_af_m" placeholder="Apellido Paterno" autocomplete="off">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                            <label for="apemat_af_m">APELLIDO MATERNO: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="apemat_af_m" name="apemat_af_m" placeholder="Apellido Materno" autocomplete="off">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="edad_af_m">EDAD: <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="edad_af_m" name="edad_af_m" placeholder="Edad" autocomplete="off">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="sexo_af_m">SEXO: <span class="text-danger">*</span></label>
                                <select class="form-control" id="sexo_af_m" name="sexo_af_m">
                                    <option value="">Seleccionar():</option>
                                    <option value="M">MASCULINO</option>
                                    <option value="F">FEMENINO</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="parentesco_af_m">PARENTESCO: <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="parentesco_af_m" name="parentesco_af_m" placeholder="Parentesco" autocomplete="off">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="numcel_af_m">N° DE CELULAR: <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="numcel_af_m" name="numcel_af_m" placeholder="Parentesco" autocomplete="off">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="estadocivil_af_m">ESTADO CIVIL: <span class="text-danger">*</span></label>
                                <select class="form-control" id="estadocivil_af_m" name="estadocivil_af_m">
                                    <option value="">Seleccionar():</option>
                                    <option value="SOLTERO">Soltero</option>
                                    <option value="CASADO">Casado</option>
                                    <option value="CONVIVIENTE">Conviviente</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="gradoins_af_m">GRADO INSTRUCCION: <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="gradoins_af_m" name="gradoins_af_m" placeholder="Grado Instruccion" autocomplete="off">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="ocupacion_af_m">OCUPACIÓN: <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="ocupacion_af_m" name="ocupacion_af_m" placeholder="Ocupacion" autocomplete="off">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="ingrsemanal_af_m">INGRESO SEMANAL S/.: <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="ingrsemanal_af_m" name="ingrsemanal_af_m" placeholder="Ingreso Semanal" autocomplete="off">
                            </div>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </form>
</div>