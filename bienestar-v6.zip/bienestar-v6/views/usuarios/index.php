<form id="frmUser" autocomplete="off">
    <div class="card mb-2">
        <div class="card-body">
            <input type="hidden" id="id_user" name="id_user">
            <div class="row">
                <div class="col-md-3">
                    <label for="">Perfil <span class="text-danger">*</span></label>
                    <div class="input-group mb-3">
                        <span class="input-group-text"><i class="fas fa-list"></i></span>
                        <select class="form-control" id="perfil" name="perfil">
                            <option value="">Seleccionar():</option>
                            <option value="Administrador">Administrador</option>
                            <option value="Alumno">Alumno</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <label for="">Usuario <span class="text-danger">*</span></label>
                    <div class="input-group mb-3">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" class="form-control" id="usuario" name="usuario" placeholder="Usuario" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-3">
                    <label for="">Contraseña <span class="text-danger">*</span></label>
                    <div class="input-group mb-3">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                        <input type="password" class="form-control" id="contrasena" name="contrasena" placeholder="Contraseña">
                    </div>
                </div>
                <div class="col-md-3">
                    <label for="">Estado <span class="text-danger">*</span></label>
                    <div class="input-group mb-3">
                        <span class="input-group-text"><i class="fas fa-list"></i></span>
                        <select name="estado" id="estado" class="form-control">
                            <option value="">Seleccionar():</option>    
                            <option value="Activo">Activo</option>
                            <option value="Inactivo">Inactivo</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer text-end">
            <button type="button" class="btn btn-danger" id="btn-nuevo">Nuevo</button>
            <button type="submit" class="btn btn-primary" id="btn-save">Guardar</button>
        </div>
    </div>
</form>
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover" style="width: 100%;" id="table_users">
                <thead>
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Perfil</th>
                        <th scope="col">Usuario</th>
                        <th scope="col">Estado</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>

                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="modalPermiso" class="modal fade" role="dialog">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Agregar permisos</h5>
                <button class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- html permisos -->
                <form id="frmPermiso">

                </form>
            </div>
        </div>
    </div>
</div>