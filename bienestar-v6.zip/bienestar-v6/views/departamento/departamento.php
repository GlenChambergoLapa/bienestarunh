<!-- DEPARTAMENTO -->
<form id="frmDepartamento" method="POST" autocomplete="off">
    <div class="card mb-2">
        <div class="card-header">
            <h3 class="card-title">DEPARTAMENTO</h3>
        </div>
        <div class="card-body">
            <input type="hidden" id="id_departamento_d" name="id_departamento_d">

            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="nombre_d">Nombre: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="nombre_d" name="nombre_d" placeholder="Departamento" autocomplete="off">
                    </div>
                </div>
            </div>

        </div>
        <div class="card-footer text-end">
            <button type="button" class="btn btn-danger" id="btn-nuevo-d">Nuevo</button>
            <button type="submit" class="btn btn-primary" id="btn-save-d">Guardar</button>
        </div>
    </div>
</form>


<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover" style="width: 100%;" id="tabla_departamento">
            
                <thead>
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Nombre</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>

                </tbody>
            </table>
        </div>
    </div>
</div>