<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover" style="width: 100%;" id="table_listaestudiantesfs">
                <thead>
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Nombres y Apellidos</th>
                        <th scope="col">DNI</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>

                </tbody>
            </table>
        </div>
    </div>

    <div class="card-footer text-end">
        <a href="views/fichasocioeconomica/fichasocioeconomicapdf.php" target="_blank" class="btn btn-danger">Generar PDF</a>
    </div>
</div>