<?php
require_once '../models/fichasocioeconomica.php';
$fichasocioeconomica = new FichaSocioeconomicaModel();

$idalumno=$_REQUEST['idal'];

foreach ($fichasocioeconomica->getDatosInfoAlumno($idalumno) as $row) {
    $apellidosnombres_dg = $row['ApellidoPaterno'].' '.$row['ApellidoMaterno'].' '.$row['Nombre'];
    $fechanacimiento_dg = date("d/m/Y", strtotime($row['FechaNacimiento']));
    $edad_dg = $row['Edad'];
    $genero_dg = $row['Genero'];
    $dni_dg = $row['DNI'];
    $telefono_dg = $row['Telefono'];
    $correo_dg = $row['Correo'];
    $domicilioactual_dg = $row['Direccion'];
    $anexoda_dg = $row['Anexo'];
    $referenciada_dg = $row['Referencia'];
    $lugarnacimiento_dg = $row['Lugar'];
    $anexoln_dg = $row['Anexo_ln'];
    $estadocivil_dg = $row['EstadoCivil'];
    $numhijos_dg = $row['NumeroHijos'];
    $iddistritoda_dg = $row['IdDistrito'];
}

// Departamento, provincia y distrito de Domicilio Alumno
foreach ($fichasocioeconomica->getDatosDomicilioAlumno($idalumno) as $row) {
    $departamentoda_dg = $row['nomdepartamento'];
    $provinciada_dg = $row['nomprovincia'];
    $distritoda_dg = $row['nomdistrito'];
}

// Departamento, provincia y distrito de Lugar Nacimiento Alumno
foreach ($fichasocioeconomica->getDatosNacimientoAlumno($idalumno) as $row) {
    $departamentoln_dg = $row['nomdepartamento'];
    $provincialn_dg = $row['nomprovincia'];
    $distritoln_dg = $row['nomdistrito'];
}

// ASPECTO ACADEMICO

foreach ($fichasocioeconomica->getAspectoAcademico($idalumno) as $row) {
    $valorcarrera = '/ '.$row['Carrera'];
    if ($row['Carrera'] == "NA"){
        $valorcarrera = "";
    }
    $carrera_aa = $row['Filial'].'/ '.$row['Facultad'].'/ '.$row['Escuela'].$valorcarrera;

    $codigomatricula_aa = $row['CodigoMatricula'];
    $ciclo_aa = $row['Ciclo'];
    $segundacarrera_aa = $row['SegundaCarrera'];
    $promedioanterior_aa = $row['PromedioAnterior'];
    $cursosdesaprobados_aa = $row['CursosDesaprobados'];

    $cursoscargo_aa = $row['CursosCargo'];
    $modalidadingreso_aa = $row['ModalidadIngreso'];
    $abandono_aa = $row['Abandono'];
    $motivo_aa = $row['Motivo'];
}

// ASPECTO FAMILIA
foreach ($fichasocioeconomica->getAspectoFamilia($idalumno) as $row) {
    $padres_af = $row['EstadoCPadres'];
    $orfandad_af = $row['Orfandad'];
    $hermanos_af = $row['Hermanos'];
    $vivecon_af = $row['Vivecon'];
    $otros_af = $row['Otros'];
}

// ASPECTO ECONOMICA
foreach ($fichasocioeconomica->getAspectoEconomica($idalumno) as $row) {
    $dependencia_ie = $row['Dependencia'];
    $otrosde_ie = $row['Otrosde'];
    $ingresofamsemanal_ie = $row['IngresoFamSemanal'];
    $actividadeconomica_ie = $row['ActividadEconomica'];
    $especificar_ie = $row['Especificar_ie'];
    $ingresosemanal_ie = $row['IngresoSemanal'];
}

// ASPECTO VIVIENDA
foreach ($fichasocioeconomica->getAspectoVivienda($idalumno) as $row) {
    $viveen_iv = $row['ViveEn'];
    $otroviveen_iv = $row['Otroviveen'];
    $material_iv = $row['Material'];
    $otromat_iv = $row['Otromat'];
    $estado_iv = $row['Estado'];
    $servicio_iv = $row['Servicio'];
    $equipamiento_iv = $row['Equipamiento'];
}

// ASPECTO ALIMENTACION
foreach ($fichasocioeconomica->getAspectoAlimentacion($idalumno) as $row) {
    $cocinagas_ia = $row['CocinaGas'];
    $detalle_ia = $row['Detalle'];
    $tipococina_ia = $row['TipoCocina'];
    $comedoruniv_ia = $row['ComedorUniv'];
}

// ASPECTO SALUD
foreach ($fichasocioeconomica->getAspectoSalud($idalumno) as $row) {
    $seguro_as = $row['Seguro'];
    $tiposeguro_as = $row['TipoSeguro'];
    $parentesco_as = $row['ParienteContacto'];
    $numerocontacto_as = $row['NumeroContacto'];

    $psusted_as = $row['PSUsted'];
    $psusteddet_as = $row['PSUstedDetalle'];
    $pspadre_as = $row['PSPadre'];
    $pspadredet_as = $row['PSPadreDetalle'];
    $psmadre_as = $row['PSMadre'];
    $psmadredet_as = $row['PSMadreDetalle'];
    $pshermano_as = $row['PSHermano'];
    $pshermanodet_as = $row['PSHermanoDetalle'];
    $psotro_as = $row['PSOtro'];
    $psotrodet_as = $row['PSOtroDetalle'];

    $dusted_as = $row['DUsted'];
    $dusteddet_as = $row['DUstedDetalle'];
    $dpadre_as = $row['DPadre'];
    $dpadredet_as = $row['DPadreDetalle'];
    $dmadre_as = $row['DMadre'];
    $dmadredet_as = $row['DMadreDetalle'];
    $dhermano_as = $row['DHermano'];
    $dhermanodet_as = $row['DHermanoDetalle'];
    $dotro_as = $row['DOtro'];
    $dotrodet_as = $row['DOtroDetalle'];
}

// ASPECTO PSICOSOCIAL
foreach ($fichasocioeconomica->getAspectoPsicosocial($idalumno) as $row) {
    $peconomico_ap = $row['PEconomico'];
    $palimentacion_ap = $row['PAlimentacion'];
    $pvivienda_ap = $row['PVivienda'];
    $ptransporte_ap = $row['PTransporte'];
    $pfamiliar_ap = $row['PFamiliar'];
    $ppsicologico_ap = $row['PPsicologico'];
    $alcohol_ap = $row['Alcohol'];
    $parentescoalcohol_ap = $row['ParentescoAlcohol'];
    $violencia_ap = $row['Violencia'];
    $detalleviolencia_ap = $row['DetalleViolencia'];
    $puniversidad_ap = $row['PUniversidad'];
    $pvive_ap = $row['PVive'];
}


// Include the main TCPDF library (search for installation path).
require_once('tcpdf/tcpdf.php');

// Extend the TCPDF class to create custom Header and Footer
class MYPDF extends TCPDF {

    //Page header
    public function Header() {
        // Logo
        $image_file = K_PATH_IMAGES.'logobienestar.jpg';
        $this->Image($image_file, 10, 10, 30, '', 'JPG', '', 'T', false, 300, '', false, false, 0, false, false, false);
        // Set font
        $this->SetFont('helvetica', 'B', 20);
        // Title
        $this->Cell(0, 15, utf8_decode(''), 0, 1, 'C', 0, '', 0, false, 'M', 'M');
        $this->Cell(0, 15, utf8_decode('FICHA SOCIOECONOMICA'), 0, 1, 'C', 0, '', 0, false, 'M', 'M');
    }

    // Page footer
    public function Footer() {
        // Position at 15 mm from bottom
        $this->SetY(-15);
        // Set font
        $this->SetFont('helvetica', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }
}

// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Direccion de Bienestar - UNH');
$pdf->SetTitle('Ficha Socioeconomica');
$pdf->SetSubject('Ficha Socioeconomica');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE, PDF_HEADER_STRING);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
    require_once(dirname(__FILE__).'/lang/eng.php');
    $pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

// set font
$pdf->SetFont('times', 'B', 8);

// add a page
$pdf->AddPage();

$html = '';

$html.='
    <style>
        table{
            border-collapse:collapse;

        }
        table > tr > th {
            font-weight: bold; 
            text-align: center;
            vertical-align: middle;
            color: black;
            height: 10px;
            border: 1px solid black;
            margin: 15px;
            padding: 15px;
            border-collapse:collapse;
        }

        table > tr > td {
            color: black;
            height: 10px;
            border: 1px solid black;
            text-align: center;
            margin:10px
            padding:10px
        }
    </style>
    
    <table width="100%">
        <tr>
            <th colspan="10" style="background-color: #C0C0C0;">I. DATOS GENERALES</th>
        </tr>
        <tr>
            <td width="25%" style="text-align: left;background-color: #C0C0C0;">APELLIDOS Y NOMBRES</td>
            <td width="75%" style="background-color: #FFFFFF;">'.$apellidosnombres_dg.'</td>
        </tr>
        <tr>
            <td width="25%" style="text-align: left;background-color: #C0C0C0;">FECHA DE NACIMIENTO</td>
            <td width="15%" style="background-color: #FFFFFF;">'.$fechanacimiento_dg.'</td>
            <td width="8%" style="text-align: left;background-color: #C0C0C0;">EDAD</td>
            <td width="8%" style="background-color: #FFFFFF;">'.$edad_dg.'</td>
            <td width="10%" style="text-align: left;background-color: #C0C0C0;">GÉNERO</td>
            <td width="14%" style="background-color: #FFFFFF;">'.$genero_dg.'</td>
            <td width="5%" style="text-align: left;background-color: #C0C0C0;">DNI</td>
            <td width="15%" style="background-color: #FFFFFF;">'.$dni_dg.'</td>
        </tr>
        <tr>
            <td width="25%" style="text-align: left;background-color: #C0C0C0;">TELEFONO/CELULAR</td>
            <td width="20%" style="background-color: #FFFFFF;">'.$telefono_dg.'</td>
            <td width="15%" style="text-align: left;background-color: #C0C0C0;">Email:</td>
            <td width="40%" style="background-color: #FFFFFF;">'.$correo_dg.'.comcomco</td>
        </tr>
        <tr>
            <td width="25%" style="text-align: left;background-color: #C0C0C0;">DOMICILIO ACTUAL</td>
            <td width="75%" style="background-color: #FFFFFF;">'.$domicilioactual_dg.'</td>
        </tr>
        <tr>
            <td width="7%" style="text-align: left;background-color: #C0C0C0;">DPT.</td>
            <td width="15%" style="background-color: #FFFFFF;">'.$departamentoda_dg.'</td>
            <td width="7%" style="text-align: left;background-color: #C0C0C0;">PROV.</td>
            <td width="15%" style="background-color: #FFFFFF;">'.$provinciada_dg.'</td>
            <td width="7%" style="text-align: left;background-color: #C0C0C0;">DIST.</td>
            <td width="15%" style="background-color: #FFFFFF;">'.$distritoda_dg.'</td>
            <td width="10%" style="text-align: left;background-color: #C0C0C0;">ANEXO</td>
            <td width="24%" style="background-color: #FFFFFF;">'.$anexoda_dg.'</td>
        </tr>
        <tr>
            <td width="35%" style="text-align: left;background-color: #C0C0C0;">REFERENCIA DE SU DOMICILIO</td>
            <td width="65%" style="background-color: #FFFFFF;">'.$referenciada_dg.'</td>
        </tr>
        <tr>
            <td width="21%" style="text-align: left;background-color: #C0C0C0;">LUGAR DE NACIMIENTO</td>
            <td width="12%" style="background-color: #FFFFFF;">'.$lugarnacimiento_dg.'</td>
            <td width="5%" style="text-align: left;background-color: #C0C0C0;">DPT.</td>
            <td width="9%" style="background-color: #FFFFFF;">'.$departamentoln_dg.'</td>
            <td width="6%" style="text-align: left;background-color: #C0C0C0;">PROV.</td>
            <td width="11%" style="background-color: #FFFFFF;">'.$provincialn_dg.'</td>
            <td width="6%" style="text-align: left;background-color: #C0C0C0;">DIST.</td>
            <td width="12%" style="background-color: #FFFFFF;">'.$distritoln_dg.'</td>
            <td width="7%" style="text-align: left;background-color: #C0C0C0;">ANEXO</td>
            <td width="11%" style="background-color: #FFFFFF;">'.$anexoln_dg.'</td>
        </tr>
        <tr>
            <td width="25%" style="text-align: left;background-color: #C0C0C0;">ESTADO CIVIL</td>
            <td width="20%" style="background-color: #FFFFFF;">'.$estadocivil_dg.'</td>
            <td width="15%" style="text-align: left;background-color: #C0C0C0;">N° DE HIJOS</td>
            <td width="40%" style="background-color: #FFFFFF;">'.$numhijos_dg.'</td>
        </tr>
        
        <tr>
            <th width="100%" style="background-color: #C0C0C0;">II. ASPECTO ACADÉMICO</th>
        </tr>
        <tr>
            <td width="23%" style="text-align: left;background-color: #C0C0C0;">ESCUELA PROFESIONAL</td>
            <td width="77%" style="background-color: #FFFFFF;">'.$carrera_aa.'</td>
        </tr>
        <tr>
            <td width="25%" style="text-align: left;background-color: #C0C0C0;">CÓDIGO DE MATRICULA</td>
            <td width="15%" style="background-color: #FFFFFF;">'.$codigomatricula_aa.'</td>
            <td width="15%" style="text-align: left;background-color: #C0C0C0;">CICLO</td>
            <td width="15%" style="background-color: #FFFFFF;">'.$ciclo_aa.'</td>
            <td width="15%" style="text-align: left;background-color: #C0C0C0;">2da CARRERA</td>
            <td width="15%" style="background-color: #FFFFFF;">'.$segundacarrera_aa.'</td>
        </tr>
        <tr>
            <td width="40%" style="text-align: left;background-color: #C0C0C0;">PROMEDIO PONDERADO DEL CICLO ANTERIOR</td>
            <td width="60%" style="background-color: #FFFFFF;">'.$promedioanterior_aa.'</td>
        </tr>
        <tr>
            <td width="50%" style="text-align: left;background-color: #C0C0C0;">N° DE CURSO DESAPROBADO DEL CICLO ANTERIOR</td>
            <td width="50%" style="background-color: #FFFFFF;">'.$cursosdesaprobados_aa.'</td>
        </tr>
        <tr>
            <td width="40%" style="text-align: left;background-color: #C0C0C0;">N° DE CURSOS A CARGO</td>
            <td width="60%" style="background-color: #FFFFFF;">'.$cursoscargo_aa.'</td>
        </tr>
        <tr>
            <td width="40%" style="text-align: left;background-color: #C0C0C0;">MODALIDAD DE INGRESO A LA UNH</td>
            <td width="60%" style="background-color: #FFFFFF;">'.$modalidadingreso_aa.'</td>
        </tr>
        <tr>
            <td width="25%" style="text-align: left;background-color: #C0C0C0;">ABANDONÓ SUS ESTUDIOS</td>
            <td width="25%" style="background-color: #FFFFFF;">'.$abandono_aa.'</td>
            <td width="25%" style="text-align: left;background-color: #C0C0C0;">MOTIVO</td>
            <td width="25%" style="background-color: #FFFFFF;">'.$motivo_aa.'</td>
        </tr>

        <tr>
            <th width="100%" style="background-color: #C0C0C0;">III. ASPECTO FAMILIA</th>
        </tr>
        <tr>
            <td width="25%" style="text-align: left;background-color: #C0C0C0;">PADRES</td>
            <td width="75%" style="background-color: #FFFFFF;">'.$padres_af.'</td>
        </tr>
        <tr>
            <td width="25%" style="text-align: left;background-color: #C0C0C0;">ORFANDAD</td>
            <td width="75%" style="background-color: #FFFFFF;">'.$orfandad_af.'</td>
        </tr>
        <tr>
            <td width="25%" style="text-align: left;background-color: #C0C0C0;">VIVE ACTUALMENTE CON</td>
            <td width="75%" style="background-color: #FFFFFF;">'.$vivecon_af.'</td>
        </tr>
        <tr>
            <td width="25%" style="text-align: left;background-color: #C0C0C0;">Otros especifique</td>
            <td width="75%" style="background-color: #FFFFFF;">'.$otros_af.'</td>
        </tr>
        <tr>
            <td width="55%" style="text-align: left;background-color: #C0C0C0;">N° DE  HERMANOS QUE DEPENDEN DE LOS PADRES</td>
            <td width="45%" style="background-color: #FFFFFF;">'.$hermanos_af.'</td>
        </tr>
        <tr>
            <td width="100%" style="text-align: left;"><h1><u>ESTRUCTURA FAMILIAR</u></h1   ><br>* Indicar tus familiares que viven en tu casa y que dependen económicamente.</td>
        </tr>
        <tr>
            <td width="21%" style="text-align: left;background-color: #C0C0C0;">APELLIDOS Y NOMBRES</td>
            <td width="6%" style="text-align: left;background-color: #C0C0C0;">EDAD</td>
            <td width="6%" style="text-align: left;background-color: #C0C0C0;">SEXO</td>
            <td width="12%" style="text-align: left;background-color: #C0C0C0;">PARENTESCO</td>
            <td width="14%" style="text-align: left;background-color: #C0C0C0;">N° DE CELULAR</td>
            <td width="10%" style="text-align: left;background-color: #C0C0C0;">EST. CIVIL</td>
            <td width="10%" style="text-align: left;background-color: #C0C0C0;">GRADO INSTRUC.</td>
            <td width="11%" style="text-align: left;background-color: #C0C0C0;">OCUPACIÓN</td>
            <td width="10%" style="text-align: left;background-color: #C0C0C0;">INGRESO SEMANAL S/.</td>
        </tr>
        ';
        // ESTRUCTURA FAMILIAR
        foreach ($fichasocioeconomica->getEstructuraFamAspectoFamilia($idalumno) as $row) {
            
            $html.= '
            <tr nobr="true" bgcolor="white">
                <td width="21%" style="text-align: center;">'.$row['ApellidosNombres'].'</td>
                <td width="6%" style="text-align: center;">'.$row['Edad'].'</td>
                <td width="6%" style="text-align: center;">'.$row['Sexo'].'</td>
                <td width="12%" style="text-align: center;">'.$row['Parentesco'].'</td>
                <td width="14%" style="text-align: center;">'.$row['Celular'].'</td>
                <td width="10%" style="text-align: center;">'.$row['EstadoCivil'].'</td>
                <td width="10%" style="text-align: center;">'.$row['GradoInstruccion'].'</td>
                <td width="11%" style="text-align: center;">'.$row['Ocupacion'].'</td>
                <td width="10%" style="text-align: center;">'.$row['IngresoSemanal'].'</td>

            </tr>
	    ';
        }
            
        $html.= '
                
        <tr>
            <th width="100%" style="background-color: #C0C0C0;">IV. ASPECTO ECONÓMICO</th>
        </tr>
        <tr>
            <td width="30%" style="text-align: left;background-color: #C0C0C0;">DEPENDE ECONÓMICAMENTE DE</td>
            <td width="70%" style="background-color: #FFFFFF;">'.$dependencia_ie.'</td>
        </tr>
        <tr>
            <td width="20%" style="text-align: left;background-color: #C0C0C0;">Otros Especifique</td>
            <td width="80%" style="background-color: #FFFFFF;">'.$otrosde_ie.'</td>
        </tr>
        <tr>
            <td width="30%" style="text-align: left;background-color: #C0C0C0;">INGRESO FAMILIAR SEMANAL: S/.</td>
            <td width="70%" style="background-color: #FFFFFF;">'.$ingresofamsemanal_ie.'</td>
        </tr>
        <tr>
            <td width="45%" style="text-align: left;background-color: #C0C0C0;">USTED DESEMPEÑAALGUNA ACTIVIDAD ECONÓMICA</td>
            <td width="10%" style="background-color: #FFFFFF;">'.$actividadeconomica_ie.'</td>
            <td width="10%" style="text-align: left;background-color: #C0C0C0;">Especifique</td>
            <td width="35%" style="background-color: #FFFFFF;">'.$especificar_ie.'</td>
        </tr>
        <tr>
            <td width="15%" style="text-align: left;background-color: #C0C0C0;">Ingreso semanal S/.</td>
            <td width="85%" style="background-color: #FFFFFF;">'.$ingresosemanal_ie.'</td>
        </tr>

        <tr>
            <th width="100%" style="background-color: #C0C0C0;">V. ASPECTO VIVIENDA</th>
        </tr>
        <tr>
            <td width="10%" style="text-align: left;background-color: #C0C0C0;">VIVE EN</td>
            <td width="20%" style="background-color: #FFFFFF;">'.$viveen_iv.'</td>
            <td width="20%" style="text-align: left;background-color: #C0C0C0;">Otros Especifique</td>
            <td width="50%" style="background-color: #FFFFFF;">'.$otroviveen_iv.'</td>
        </tr>
        <tr>
            <td width="30%" style="text-align: left;background-color: #C0C0C0;">MATERIAL DE CONSTRUCCIÓN</td>
            <td width="15%" style="background-color: #FFFFFF;">'.$material_iv.'</td>
            <td width="15%" style="text-align: left;background-color: #C0C0C0;">Otros Especifique</td>
            <td width="40%" style="background-color: #FFFFFF;">'.$otromat_iv.'</td>
        </tr>
        <tr>
            <td width="30%" style="text-align: left;background-color: #C0C0C0;">ESTADO DE CONSTRUCCIÓN</td>
            <td width="70%" style="background-color: #FFFFFF;">'.$estado_iv.'</td>
        </tr>
        <tr>
            <td width="30%" style="text-align: left;background-color: #C0C0C0;">SERVICIO DE VIVIENDA</td>
            <td width="70%" style="background-color: #FFFFFF;">'.$servicio_iv.'</td>
        </tr>
        
        <tr>
            <td width="40%" style="text-align: left;background-color: #C0C0C0;">EN LA CASA O CUARTO QUE VIVES CUENTA CON</td>
            <td width="60%" style="background-color: #FFFFFF;">'.$equipamiento_iv.'</td>
        </tr>

        <tr>
            <th width="100%" style="background-color: #C0C0C0;">VI. ASPECTO ALIMENTACIÓN</th>
        </tr>
        <tr>
            <td width="30%" style="text-align: left;background-color: #C0C0C0;">¿COCINA EN SU CASA O CUARTO?</td>
            <td width="10%" style="background-color: #FFFFFF;">'.$cocinagas_ia.'</td>
            <td width="15%" style="text-align: left;background-color: #C0C0C0;">Especifique</td>
            <td width="45%" style="background-color: #FFFFFF;">'.$detalle_ia.'</td>
        </tr>
        <tr>
            <td width="25%" style="text-align: left;background-color: #C0C0C0;">PREPARA TUS ALIMENTOS</td>
            <td width="10%" style="background-color: #FFFFFF;">'.$tipococina_ia.'</td>
            <td width="55%" style="text-align: left;background-color: #C0C0C0;">TUVO ACCESO A COMEDOR UNIVERSITARIO CICLOS ANTERIORES</td>
            <td width="10%" style="background-color: #FFFFFF;">'.$comedoruniv_ia.'</td>
        </tr>
        
        <tr>
            <th width="100%" style="background-color: #C0C0C0;">VII. ASPECTO SALUD</th>
        </tr>
        <tr>
            <th width="100%">&nbsp;</th>
        </tr>
        
        <tr>
            <td rowspan="2" width="20%" style="text-center: left;background-color: #C0C0C0;">PARENTESCO</td>
            <td width="12%" colspan="2" style="text-center: left;background-color: #C0C0C0;">PROBLEMAS DE SALUD</td>
            <td rowspan="2" width="13%" style="text-align: center;background-color: #C0C0C0;">ESPECIFIQUE</td>
            <td rowspan="2" width="2%" style="text-align: center;">&nbsp;</td>
            <td rowspan="2" width="20%" style="text-center: left;background-color: #C0C0C0;">PARENTESCO</td>
            <td width="14%" colspan="2" style="text-center: left;background-color: #C0C0C0;">DISCAPACIDAD</td>
            <td rowspan="2" width="19%" style="text-align: center;background-color: #C0C0C0;">ESPECIFIQUE, *Certificado CONADIS</td>
        </tr>
        <tr>
            <td width="6%" style="text-align: center;background-color: #C0C0C0;">SI</td>
            <td width="6%" style="text-align: center;background-color: #C0C0C0;">NO</td>
            <td width="7%" style="text-align: center;background-color: #C0C0C0;">SI</td>
            <td width="7%" style="text-align: center;background-color: #C0C0C0;">NO</td>
        </tr>

        <tr>
            <td width="20%" style="text-align: center;">ESTUDIANTE</td>';
            // CONDICION DE SI/NO DE PROBLEMA SALUD
            if ($psusted_as == "SI"){
                
            $html.= '
                <td width="6%" style="text-align: center;">'.$psusted_as.'</td>
                <td width="6%" style="text-align: center;"></td>
            ';
            }else{
            $html.= '
                <td width="6%" style="text-align: center;"></td>
                <td width="6%" style="text-align: center;">'.$psusted_as.'</td>
            ';
            }
                
            $html.= '
            
            <td width="13%" style="text-align: center;">'.$psusteddet_as.'</td>
            <td width="2%" style="text-align: center;">&nbsp;</td>
            <td width="20%" style="text-align: center;">ESTUDIANTE</td>';

            // CONDICION DE SI/NO DE DISCAPACIDAD
            if ($dusted_as == "SI"){
                
            $html.= '
                <td width="7%" style="text-align: center;">'.$dusted_as.'</td>
                <td width="7%" style="text-align: center;"></td>
            ';
            }else{
            $html.= '
                <td width="7%" style="text-align: center;"></td>
                <td width="7%" style="text-align: center;">'.$dusted_as.'</td>
            ';
            }

            $html.= '
            <td width="19%" style="text-align: center;">'.$dusteddet_as.'</td>
        </tr>

        <tr>
            <td width="20%" style="text-align: center;">PADRE</td>';
            // CONDICION DE SI/NO DE PROBLEMA SALUD
            if ($pspadre_as == "SI"){
                
            $html.= '
                <td width="6%" style="text-align: center;">'.$pspadre_as.'</td>
                <td width="6%" style="text-align: center;"></td>
            ';
            }else{
            $html.= '
                <td width="6%" style="text-align: center;"></td>
                <td width="6%" style="text-align: center;">'.$pspadre_as.'</td>
            ';
            }
                
            $html.= '
            
            <td width="13%" style="text-align: center;">'.$pspadredet_as.'</td>
            <td width="2%" style="text-align: center;">&nbsp;</td>
            <td width="20%" style="text-align: center;">PADRE</td>';

            // CONDICION DE SI/NO DE DISCAPACIDAD
            if ($dpadre_as == "SI"){
                
            $html.= '
                <td width="7%" style="text-align: center;">'.$dpadre_as.'</td>
                <td width="7%" style="text-align: center;"></td>
            ';
            }else{
            $html.= '
                <td width="7%" style="text-align: center;"></td>
                <td width="7%" style="text-align: center;">'.$dpadre_as.'</td>
            ';
            }

            $html.= '
            <td width="19%" style="text-align: center;">'.$dpadredet_as.'</td>
        </tr>

        <tr>
            <td width="20%" style="text-align: center;">MADRE</td>';
            // CONDICION DE SI/NO DE PROBLEMA SALUD
            if ($psmadre_as == "SI"){
                
            $html.= '
                <td width="6%" style="text-align: center;">'.$psmadre_as.'</td>
                <td width="6%" style="text-align: center;"></td>
            ';
            }else{
            $html.= '
                <td width="6%" style="text-align: center;"></td>
                <td width="6%" style="text-align: center;">'.$psmadre_as.'</td>
            ';
            }
                
            $html.= '
            
            <td width="13%" style="text-align: center;">'.$psmadredet_as.'</td>
            <td width="2%" style="text-align: center;">&nbsp;</td>
            <td width="20%" style="text-align: center;">MADRE</td>';

            // CONDICION DE SI/NO DE DISCAPACIDAD
            if ($dmadre_as == "SI"){
                
            $html.= '
                <td width="7%" style="text-align: center;">'.$dmadre_as.'</td>
                <td width="7%" style="text-align: center;"></td>
            ';
            }else{
            $html.= '
                <td width="7%" style="text-align: center;"></td>
                <td width="7%" style="text-align: center;">'.$dmadre_as.'</td>
            ';
            }

            $html.= '
            <td width="19%" style="text-align: center;">'.$dmadredet_as.'</td>
        </tr>

        <tr>
            <td width="20%" style="text-align: center;">HERMANO</td>';
            // CONDICION DE SI/NO DE PROBLEMA SALUD
            if ($pshermano_as == "SI"){
                
            $html.= '
                <td width="6%" style="text-align: center;">'.$pshermano_as.'</td>
                <td width="6%" style="text-align: center;"></td>
            ';
            }else{
            $html.= '
                <td width="6%" style="text-align: center;"></td>
                <td width="6%" style="text-align: center;">'.$pshermano_as.'</td>
            ';
            }
                
            $html.= '
            
            <td width="13%" style="text-align: center;">'.$pshermanodet_as.'</td>
            <td width="2%" style="text-align: center;">&nbsp;</td>
            <td width="20%" style="text-align: center;">HERMANO</td>';

            // CONDICION DE SI/NO DE DISCAPACIDAD
            if ($dhermano_as == "SI"){
                
            $html.= '
                <td width="7%" style="text-align: center;">'.$dhermano_as.'</td>
                <td width="7%" style="text-align: center;"></td>
            ';
            }else{
            $html.= '
                <td width="7%" style="text-align: center;"></td>
                <td width="7%" style="text-align: center;">'.$dhermano_as.'</td>
            ';
            }

            $html.= '
            <td width="19%" style="text-align: center;">'.$dhermanodet_as.'</td>
        </tr>

        <tr>
            <td width="20%" style="text-align: center;">OTRO</td>';
            // CONDICION DE SI/NO DE PROBLEMA SALUD
            if ($psotro_as == "SI"){
                
            $html.= '
                <td width="6%" style="text-align: center;">'.$psotro_as.'</td>
                <td width="6%" style="text-align: center;"></td>
            ';
            }else{
            $html.= '
                <td width="6%" style="text-align: center;"></td>
                <td width="6%" style="text-align: center;">'.$psotro_as.'</td>
            ';
            }
                
            $html.= '
            
            <td width="13%" style="text-align: center;">'.$psotrodet_as.'</td>
            <td width="2%" style="text-align: center;">&nbsp;</td>
            <td width="20%" style="text-align: center;">OTRO</td>';

            // CONDICION DE SI/NO DE DISCAPACIDAD
            if ($dotro_as == "SI"){
                
            $html.= '
                <td width="7%" style="text-align: center;">'.$dotro_as.'</td>
                <td width="7%" style="text-align: center;"></td>
            ';
            }else{
            $html.= '
                <td width="7%" style="text-align: center;"></td>
                <td width="7%" style="text-align: center;">'.$dotro_as.'</td>
            ';
            }

            $html.= '
            <td width="19%" style="text-align: center;">'.$dotrodet_as.'</td>
        </tr>

        <tr>
            <th width="100%">&nbsp;</th>
        </tr>
        <tr>
            <td width="22%" style="text-align: left;background-color: #C0C0C0;">TIENE SEGURO DE SALUD</td>
            <td width="6%" style="background-color: #FFFFFF;">'.$seguro_as.'</td>
            <td width="24%" style="text-align: left;background-color: #C0C0C0;">TIPO DE SEGURO DE SALUD</td>
            <td width="48%" style="background-color: #FFFFFF;">'.$tiposeguro_as.'</td>
        </tr>
        <tr>
            <td width="40%" rowspan="2" style="text-align: left;background-color: #C0C0C0;">EN CASO DE EMERGENCIA COMUNICARSE CON</td>
            <td width="30%" style="text-align: center;background-color: #C0C0C0;">Parentesco</td>
            <td width="30%" style="text-align: center;background-color: #C0C0C0;">N° de celular</td>
        </tr>
        <tr>
            <td width="30%" style="text-align: center">'.$parentesco_as.'</td>
            <td width="30%" style="text-align: center;">'.$numerocontacto_as.'</td>
        </tr>

        <tr>
            <th width="100%" style="background-color: #C0C0C0;">VIII. ASPECTO PSICOSOCIAL</th>
        </tr>
        <tr>
            <td width="100%" style="text-align: left;">¿Qué problemas presentas actualmente? Describir</td>
        </tr>
        <tr>
            <td width="15%" style="text-align: left;background-color: #C0C0C0;">ECONÓMICO</td>
            <td width="85%" style="text-align: center;">'.$peconomico_ap.'</td>
        </tr>
        <tr>
            <td width="15%" style="text-align: left;background-color: #C0C0C0;">ALIMENTACIÓN</td>
            <td width="85%" style="text-align: center;">'.$palimentacion_ap.'</td>
        </tr>
        <tr>
            <td width="15%" style="text-align: left;background-color: #C0C0C0;">VIVIENDA</td>
            <td width="85%" style="text-align: center;">'.$pvivienda_ap.'</td>
        </tr>
        <tr>
            <td width="15%" style="text-align: left;background-color: #C0C0C0;">TRANSPORTE</td>
            <td width="85%" style="text-align: center;">'.$ptransporte_ap.'</td>
        </tr>
        <tr>
            <td width="15%" style="text-align: left;background-color: #C0C0C0;">FAMILIAR</td>
            <td width="85%" style="text-align: center;">'.$pfamiliar_ap.'</td>
        </tr>
        <tr>
            <td width="15%" style="text-align: left;background-color: #C0C0C0;">PSICOLÓGICO</td>
            <td width="85%" style="text-align: center;">'.$ppsicologico_ap.'</td>
        </tr>
        <tr>
            <td width="60%" style="text-align: left;background-color: #C0C0C0;">¿TIENES ALGÚN FAMILIAR QUE CONSUME ALCOHOL FRECUENTEMENTE?</td>
            <td width="10%" style="text-align: center;">'.$alcohol_ap.'</td>
            <td width="10%" style="text-align: left;background-color: #C0C0C0;">Parentesco</td>
            <td width="20%" style="text-align: center;">'.$parentescoalcohol_ap.'</td>
        </tr>
        <tr>
            <td width="40%" style="text-align: left;background-color: #C0C0C0;">¿EXISTE MALTRATO O VIOLENCIA EN TU CASA?</td>
            <td width="10%" style="text-align: center;">'.$violencia_ap.'</td>
            <td width="10%" style="text-align: left;background-color: #C0C0C0;">Especifique</td>
            <td width="40%" style="text-align: center;">'.$detalleviolencia_ap.'</td>
        </tr>

        <tr>
            <th width="100%" style="background-color: #C0C0C0;">¿QUÉ PROBLEMAS SOCIALES HAS IDENTIFICADO EN LA UNIVERSIDAD?</th>
        </tr>
        <tr>
            <td width="100%" style="text-align: center;">'.$puniversidad_ap.'</td>
        </tr>

        <tr>
            <th width="100%" style="background-color: #C0C0C0; border">¿QUÉ PROBLEMAS SOCIALES HAS IDENTIFICADO POR EL LUGAR DONDE VIVES?</th>
        </tr>
        <tr>
            <td width="100%" style="text-align: center;">'.$pvive_ap.'</td>
        </tr>

        <tr>
            <th width="100%">&nbsp;</th>
        </tr>
        <tr>
            <td width="100%" colspan="3" style="text-align: left;">
            SUGERENCIAS<br><br>
            HAGO CONSTAR QUE LA INFORMACIÓN VERTIDA EN ESTA FICHA SOCIOECONÓMICA CORRESPONDE A LA VERDAD, DE
            VERIFICARSE LO CONTRARIO ME SOMETERÉ A LAS SANCIONES CORRESPONDIENTES.<br><br><br><br>
            <p style="text-align: rigth;">Huancavelica,... de ....de.....</p>
            <br><br>
            </td>
        </tr>
        
        <tr style="text-align: center;border-style: none;">
            <td width="30%" style="border-top: 0px solid black;"><br><br><br><br><br><br>______________________<br>Firma del estudiante</td>
            <td width="40%" style="border-top: 0px solid black;"><br><br><br><br><br><br>______________________<br>Huella</td>
            <td width="30%" style="border-top: 0px solid black;"><br><br><br><br><br><br>______________________<br>V° B° Trabajador Social</td>
        </tr>


       

    ';

    $html.=' 
            </table>';

    $pdf->writeHTML($html, true, false, false, false, 'C');

// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output('Ficha Socioeconomica.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+