<?php
date_default_timezone_set('America/Lima');
session_start();
define('RUTA', 'http://localhost:8080/asistencia/');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_NAME', 'db_bienestaruniversitario');
define('DB_PASS', '');
?>